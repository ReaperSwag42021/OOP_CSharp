namespace CarverApp.Models;

public enum ProefritStatus
{
    Gepland,
    Uitgevoerd,
    Geannuleerd
}

/// <summary>
/// Een geplande of uitgevoerde proefrit.
/// Koppelt een Prospect aan een Carver met datum/tijd en status.
/// </summary>
public class Proefrit
{
    public int Id { get; set; }
    public int ProspectId { get; set; }
    public int CarverId { get; set; }
    public DateTime DatumTijd { get; set; } = DateTime.Now.AddDays(1);
    public ProefritStatus Status { get; set; } = ProefritStatus.Gepland;
    public bool Bevestigd { get; set; }
    public string? Opmerkingen { get; set; }
    public DateTime AangemaaktOp { get; set; } = DateTime.Now;

    // Optionele navigatie voor weergave (lazy gevuld via repository)
    public Prospect? Prospect { get; set; }
    public Carver? Carver { get; set; }

    public string StatusText => Status switch
    {
        ProefritStatus.Gepland => "Gepland",
        ProefritStatus.Uitgevoerd => "Uitgevoerd",
        ProefritStatus.Geannuleerd => "Geannuleerd",
        _ => "Onbekend"
    };

    public override string ToString()
        => $"{DatumTijd:dd-MM-yyyy HH:mm} - {Prospect?.VolledigeNaam} - {Carver?.Model}";
}
