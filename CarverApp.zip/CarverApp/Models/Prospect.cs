namespace CarverApp.Models;

/// <summary>
/// Een potentiele klant die geinteresseerd is in een Carver.
/// </summary>
public class Prospect
{
    public int Id { get; set; }
    public string Voornaam { get; set; } = string.Empty;
    public string Achternaam { get; set; } = string.Empty;
    public string? Email { get; set; }
    public string? Telefoon { get; set; }
    public string? Adres { get; set; }
    public string? Postcode { get; set; }
    public string? Woonplaats { get; set; }

    public bool RijbewijsAB { get; set; }
    public bool RijbewijsAM { get; set; }
    public bool Invalidenvoertuig { get; set; }

    public string? Motivatie { get; set; }
    public DateTime AangemaaktOp { get; set; } = DateTime.Now;

    public string VolledigeNaam => $"{Voornaam} {Achternaam}".Trim();

    public override string ToString() => VolledigeNaam;
}
