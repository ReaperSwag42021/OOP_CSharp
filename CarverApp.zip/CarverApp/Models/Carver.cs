namespace CarverApp.Models;

/// <summary>
/// Een Carver-model (Base, R+, Range, S+ of Sport).
/// </summary>
public class Carver
{
    public int Id { get; set; }
    public string Model { get; set; } = string.Empty;
    public decimal Prijs { get; set; }
    public string? Omschrijving { get; set; }
    public bool Beschikbaar { get; set; } = true;

    public override string ToString() => $"{Model} - {Prijs:C0}";
}
