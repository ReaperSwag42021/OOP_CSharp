namespace CarverApp.Models;

/// <summary>
/// Administrator erft van Gebruiker en heeft extra rechten,
/// zoals het beheren van andere gebruikers.
/// </summary>
public class Administrator : Gebruiker
{
    public Administrator()
    {
        IsAdmin = true;
    }

    public override string RolNaam => "Administrator";

    /// <summary>
    /// Eenvoudige controle: een administrator mag andere gebruikers beheren.
    /// </summary>
    public bool MagGebruikersBeheren() => IsAdmin;
}
