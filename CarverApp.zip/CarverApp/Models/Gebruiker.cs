namespace CarverApp.Models;

/// <summary>
/// Basisklasse voor een ingelogde gebruiker.
/// Administrator erft van deze klasse en breidt de rechten uit.
/// </summary>
public class Gebruiker
{
    public int Id { get; set; }
    public string Gebruikersnaam { get; set; } = string.Empty;

    /// <summary>
    /// Opgeslagen wachtwoord in het formaat "base64(salt):base64(hash)".
    /// Wordt NOOIT in plain text bewaard.
    /// </summary>
    public string WachtwoordHash { get; set; } = string.Empty;

    public string VolledigeNaam { get; set; } = string.Empty;
    public bool IsAdmin { get; set; }
    public DateTime AangemaaktOp { get; set; } = DateTime.Now;

    /// <summary>
    /// Vergelijkt het opgegeven wachtwoord met de opgeslagen hash.
    /// </summary>
    public virtual bool ControleerWachtwoord(string wachtwoord)
    {
        return Helpers.PasswordHelper.Verifieer(wachtwoord, WachtwoordHash);
    }

    /// <summary>
    /// Polymorfe rolweergave (administrator overschrijft).
    /// </summary>
    public virtual string RolNaam => "Medewerker";

    public override string ToString() => $"{Gebruikersnaam} ({VolledigeNaam})";
}
