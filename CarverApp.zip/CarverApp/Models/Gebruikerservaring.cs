namespace CarverApp.Models;

/// <summary>
/// De ervaring van de prospect na afloop van de proefrit.
/// Bestaat uit antwoorden op 4 vragen: 1 = Niet mee eens, 2 = Neutraal, 3 = Mee eens.
/// </summary>
public class Gebruikerservaring
{
    public int Id { get; set; }
    public int ProefritId { get; set; }

    public int Vraag1_Rijden { get; set; }   // Rijden voldoet aan verwachting
    public int Vraag2_Prijs { get; set; }    // Prijsstelling naar wens
    public int Vraag3_Opties { get; set; }   // Extra opties toereikend
    public int Vraag4_Aanschaf { get; set; } // Gaat snel over tot aanschaf

    public DateTime AangemaaktOp { get; set; } = DateTime.Now;

    /// <summary>
    /// Gemiddelde score over alle 4 vragen (1.0 - 3.0).
    /// </summary>
    public double Gemiddelde
        => (Vraag1_Rijden + Vraag2_Prijs + Vraag3_Opties + Vraag4_Aanschaf) / 4.0;

    public static string AntwoordTekst(int score) => score switch
    {
        1 => "Niet mee eens",
        2 => "Neutraal",
        3 => "Mee eens",
        _ => "-"
    };
}
