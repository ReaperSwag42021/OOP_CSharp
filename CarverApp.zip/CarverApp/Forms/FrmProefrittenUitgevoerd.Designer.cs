namespace CarverApp.Forms;

partial class FrmProefrittenUitgevoerd
{
    private System.ComponentModel.IContainer components = null!;
    private Label lblTitel = null!;
    private ListView lvProefritten = null!;
    private Button btnErvaring = null!, btnVerversen = null!, btnSluiten = null!;
    private Label lblStatus = null!;

    protected override void Dispose(bool disposing)
    {
        if (disposing && (components != null)) components.Dispose();
        base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
        lblTitel = new Label();
        lvProefritten = new ListView();
        btnErvaring = new Button();
        btnVerversen = new Button();
        btnSluiten = new Button();
        lblStatus = new Label();
        SuspendLayout();

        lblTitel.Text = "Uitgevoerde proefritten";
        lblTitel.Font = new Font("Segoe UI", 14F, FontStyle.Bold);
        lblTitel.Location = new Point(15, 10);
        lblTitel.Size = new Size(600, 30);

        lvProefritten.Location = new Point(15, 50);
        lvProefritten.Size = new Size(740, 380);
        lvProefritten.View = View.Details;
        lvProefritten.FullRowSelect = true;
        lvProefritten.GridLines = true;
        lvProefritten.MultiSelect = false;
        lvProefritten.HideSelection = false;
        lvProefritten.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
        lvProefritten.Columns.Add("Datum/tijd",       140);
        lvProefritten.Columns.Add("Prospect",         220);
        lvProefritten.Columns.Add("Carver",           140);
        lvProefritten.Columns.Add("Ervaring ingevuld", 130);
        lvProefritten.Columns.Add("Gem. score",       100);

        btnErvaring.Text = "Ervaring vastleggen...";
        btnErvaring.Location = new Point(15, 445);
        btnErvaring.Size = new Size(170, 32);
        btnErvaring.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
        btnErvaring.Click += btnErvaring_Click;

        btnVerversen.Text = "Verversen";
        btnVerversen.Location = new Point(195, 445);
        btnVerversen.Size = new Size(100, 32);
        btnVerversen.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
        btnVerversen.Click += btnVerversen_Click;

        btnSluiten.Text = "Sluiten";
        btnSluiten.Location = new Point(660, 445);
        btnSluiten.Size = new Size(95, 32);
        btnSluiten.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;
        btnSluiten.Click += btnSluiten_Click;

        lblStatus.Location = new Point(15, 485);
        lblStatus.Size = new Size(600, 22);
        lblStatus.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
        lblStatus.ForeColor = Color.DimGray;

        AutoScaleDimensions = new SizeF(7F, 15F);
        AutoScaleMode = AutoScaleMode.Font;
        ClientSize = new Size(770, 515);
        MinimumSize = new Size(640, 400);
        Controls.AddRange(new Control[] {
            lblTitel, lvProefritten, btnErvaring, btnVerversen, btnSluiten, lblStatus
        });
        StartPosition = FormStartPosition.CenterParent;
        Text = "Uitgevoerde proefritten";
        ResumeLayout(false);
    }
}
