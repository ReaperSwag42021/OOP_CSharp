using CarverApp.Models;
using CarverApp.Repositories;

namespace CarverApp.Forms;

public partial class FrmErvaring : Form
{
    private readonly Proefrit _proefrit;
    private readonly ErvaringRepository _repo = new();

    public FrmErvaring(Proefrit proefrit)
    {
        _proefrit = proefrit ?? throw new ArgumentNullException(nameof(proefrit));
        InitializeComponent();
        lblContext.Text = $"Prospect: {proefrit.Prospect?.VolledigeNaam}    " +
                          $"Carver: {proefrit.Carver?.Model}    " +
                          $"Datum: {proefrit.DatumTijd:dd-MM-yyyy HH:mm}";
    }

    private int LeesAntwoord(RadioButton n, RadioButton neut, RadioButton m)
    {
        if (n.Checked) return 1;
        if (neut.Checked) return 2;
        if (m.Checked) return 3;
        return 0;
    }

    private void btnOpslaan_Click(object? sender, EventArgs e)
    {
        int v1 = LeesAntwoord(rbN1, rbNeu1, rbM1);
        int v2 = LeesAntwoord(rbN2, rbNeu2, rbM2);
        int v3 = LeesAntwoord(rbN3, rbNeu3, rbM3);
        int v4 = LeesAntwoord(rbN4, rbNeu4, rbM4);

        if (v1 == 0 || v2 == 0 || v3 == 0 || v4 == 0)
        {
            MessageBox.Show(this, "Beantwoord alle 4 vragen.", "Validatie",
                MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return;
        }

        try
        {
            var ervaring = new Gebruikerservaring
            {
                ProefritId = _proefrit.Id,
                Vraag1_Rijden = v1,
                Vraag2_Prijs = v2,
                Vraag3_Opties = v3,
                Vraag4_Aanschaf = v4
            };
            _repo.Opslaan(ervaring);

            MessageBox.Show(this, "Ervaring vastgelegd.", "Opgeslagen",
                MessageBoxButtons.OK, MessageBoxIcon.Information);
            DialogResult = DialogResult.OK;
            Close();
        }
        catch (Exception ex)
        {
            MessageBox.Show(this, "Opslaan mislukt:\n" + ex.Message,
                "Fout", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }

    private void btnAnnuleren_Click(object? sender, EventArgs e)
    {
        DialogResult = DialogResult.Cancel;
        Close();
    }
}
