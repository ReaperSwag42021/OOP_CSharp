namespace CarverApp.Forms;

partial class FrmLogin
{
    private System.ComponentModel.IContainer components = null!;
    private Label lblTitel = null!;
    private Label lblGebruikersnaam = null!;
    private Label lblWachtwoord = null!;
    private TextBox txtGebruikersnaam = null!;
    private TextBox txtWachtwoord = null!;
    private Button btnLogin = null!;
    private Button btnAnnuleren = null!;
    private Label lblFout = null!;

    protected override void Dispose(bool disposing)
    {
        if (disposing && (components != null))
            components.Dispose();
        base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
        lblTitel = new Label();
        lblGebruikersnaam = new Label();
        lblWachtwoord = new Label();
        txtGebruikersnaam = new TextBox();
        txtWachtwoord = new TextBox();
        btnLogin = new Button();
        btnAnnuleren = new Button();
        lblFout = new Label();
        SuspendLayout();

        // lblTitel
        lblTitel.AutoSize = false;
        lblTitel.Font = new Font("Segoe UI", 16F, FontStyle.Bold);
        lblTitel.Location = new Point(20, 20);
        lblTitel.Size = new Size(360, 40);
        lblTitel.Text = "Carver - Login";
        lblTitel.TextAlign = ContentAlignment.MiddleLeft;

        // lblGebruikersnaam
        lblGebruikersnaam.Location = new Point(20, 80);
        lblGebruikersnaam.Size = new Size(120, 23);
        lblGebruikersnaam.Text = "Gebruikersnaam:";
        lblGebruikersnaam.TextAlign = ContentAlignment.MiddleLeft;

        // txtGebruikersnaam
        txtGebruikersnaam.Location = new Point(150, 80);
        txtGebruikersnaam.Size = new Size(220, 23);

        // lblWachtwoord
        lblWachtwoord.Location = new Point(20, 115);
        lblWachtwoord.Size = new Size(120, 23);
        lblWachtwoord.Text = "Wachtwoord:";
        lblWachtwoord.TextAlign = ContentAlignment.MiddleLeft;

        // txtWachtwoord
        txtWachtwoord.Location = new Point(150, 115);
        txtWachtwoord.Size = new Size(220, 23);
        txtWachtwoord.UseSystemPasswordChar = true;

        // lblFout
        lblFout.ForeColor = Color.Firebrick;
        lblFout.Location = new Point(20, 150);
        lblFout.Size = new Size(350, 30);
        lblFout.Text = "";

        // btnLogin
        btnLogin.Location = new Point(190, 190);
        btnLogin.Size = new Size(85, 32);
        btnLogin.Text = "Inloggen";
        btnLogin.UseVisualStyleBackColor = true;
        btnLogin.Click += btnLogin_Click;

        // btnAnnuleren
        btnAnnuleren.Location = new Point(285, 190);
        btnAnnuleren.Size = new Size(85, 32);
        btnAnnuleren.Text = "Annuleren";
        btnAnnuleren.UseVisualStyleBackColor = true;
        btnAnnuleren.Click += btnAnnuleren_Click;

        // FrmLogin
        AutoScaleDimensions = new SizeF(7F, 15F);
        AutoScaleMode = AutoScaleMode.Font;
        ClientSize = new Size(394, 241);
        Controls.Add(lblTitel);
        Controls.Add(lblGebruikersnaam);
        Controls.Add(lblWachtwoord);
        Controls.Add(txtGebruikersnaam);
        Controls.Add(txtWachtwoord);
        Controls.Add(lblFout);
        Controls.Add(btnLogin);
        Controls.Add(btnAnnuleren);
        FormBorderStyle = FormBorderStyle.FixedDialog;
        MaximizeBox = false;
        MinimizeBox = false;
        StartPosition = FormStartPosition.CenterScreen;
        Text = "Carver - Login";
        ResumeLayout(false);
    }
}
