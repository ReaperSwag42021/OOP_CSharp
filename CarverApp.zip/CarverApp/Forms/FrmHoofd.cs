namespace CarverApp.Forms;

public partial class FrmHoofd : Form
{
    public FrmHoofd()
    {
        InitializeComponent();
        UpdateWelkom();

        // Verberg admin-knop voor niet-admins
        btnGebruikersbeheer.Visible = Program.HuidigeGebruiker?.IsAdmin == true;
    }

    private void UpdateWelkom()
    {
        var g = Program.HuidigeGebruiker;
        lblWelkom.Text = g is null
            ? "Welkom"
            : $"Welkom, {g.VolledigeNaam} ({g.RolNaam})";
    }

    private void btnNieuw_Click(object? sender, EventArgs e)
    {
        using var f = new FrmProefritNieuw();
        f.ShowDialog(this);
    }

    private void btnGepland_Click(object? sender, EventArgs e)
    {
        using var f = new FrmProefrittenGepland();
        f.ShowDialog(this);
    }

    private void btnUitgevoerd_Click(object? sender, EventArgs e)
    {
        using var f = new FrmProefrittenUitgevoerd();
        f.ShowDialog(this);
    }

    private void btnStatistieken_Click(object? sender, EventArgs e)
    {
        using var f = new FrmStatistieken();
        f.ShowDialog(this);
    }

    private void btnExportExcel_Click(object? sender, EventArgs e)
    {
        try
        {
            using var sfd = new SaveFileDialog
            {
                Filter = "Excel-bestand (*.xlsx)|*.xlsx",
                FileName = $"Klantenlijst_{DateTime.Now:yyyyMMdd}.xlsx"
            };
            if (sfd.ShowDialog(this) != DialogResult.OK) return;

            var prospects = new Repositories.ProspectRepository().OphalenAlle();
            Helpers.ExcelExporter.ExporteerKlantenlijst(prospects, sfd.FileName);

            MessageBox.Show(this, $"Klantenlijst geexporteerd naar:\n{sfd.FileName}",
                "Export gelukt", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
        catch (Exception ex)
        {
            MessageBox.Show(this, "Export mislukt:\n" + ex.Message,
                "Fout", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }

    private void btnGebruikersbeheer_Click(object? sender, EventArgs e)
    {
        if (Program.HuidigeGebruiker is not Models.Administrator admin || !admin.MagGebruikersBeheren())
        {
            MessageBox.Show(this, "Geen rechten voor gebruikersbeheer.",
                "Toegang geweigerd", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return;
        }

        using var f = new FrmGebruikersbeheer();
        f.ShowDialog(this);
    }

    private void btnUitloggen_Click(object? sender, EventArgs e)
    {
        Program.HuidigeGebruiker = null;
        Close();
    }
}
