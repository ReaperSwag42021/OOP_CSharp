namespace CarverApp.Forms;

partial class FrmErvaring
{
    private System.ComponentModel.IContainer components = null!;
    private Label lblTitel = null!, lblContext = null!;
    private GroupBox grpV1 = null!, grpV2 = null!, grpV3 = null!, grpV4 = null!;
    private RadioButton rbN1 = null!, rbNeu1 = null!, rbM1 = null!;
    private RadioButton rbN2 = null!, rbNeu2 = null!, rbM2 = null!;
    private RadioButton rbN3 = null!, rbNeu3 = null!, rbM3 = null!;
    private RadioButton rbN4 = null!, rbNeu4 = null!, rbM4 = null!;
    private Button btnOpslaan = null!, btnAnnuleren = null!;

    protected override void Dispose(bool disposing)
    {
        if (disposing && (components != null)) components.Dispose();
        base.Dispose(disposing);
    }

    private GroupBox MaakVraagGroup(string vraag, int y,
        out RadioButton n, out RadioButton neu, out RadioButton m)
    {
        var g = new GroupBox
        {
            Text = vraag,
            Location = new Point(15, y),
            Size = new Size(560, 70),
            Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right,
            Font = new Font("Segoe UI", 9.5F, FontStyle.Regular)
        };
        n = new RadioButton { Text = "Niet mee eens", Location = new Point(20,  30), Size = new Size(140, 22) };
        neu = new RadioButton { Text = "Neutraal",    Location = new Point(180, 30), Size = new Size(140, 22) };
        m = new RadioButton { Text = "Mee eens",      Location = new Point(340, 30), Size = new Size(140, 22) };
        g.Controls.Add(n); g.Controls.Add(neu); g.Controls.Add(m);
        return g;
    }

    private void InitializeComponent()
    {
        lblTitel = new Label();
        lblContext = new Label();
        btnOpslaan = new Button();
        btnAnnuleren = new Button();
        SuspendLayout();

        lblTitel.Text = "Gebruikerservaring";
        lblTitel.Font = new Font("Segoe UI", 14F, FontStyle.Bold);
        lblTitel.Location = new Point(15, 10);
        lblTitel.Size = new Size(560, 30);

        lblContext.Location = new Point(15, 42);
        lblContext.Size = new Size(560, 22);
        lblContext.Font = new Font("Segoe UI", 9F, FontStyle.Italic);
        lblContext.ForeColor = Color.DimGray;

        grpV1 = MaakVraagGroup("1. Het rijden in een Carver voldoet aan mijn verwachting",  75, out rbN1, out rbNeu1, out rbM1);
        grpV2 = MaakVraagGroup("2. De prijsstelling van de Carver is naar wens",           155, out rbN2, out rbNeu2, out rbM2);
        grpV3 = MaakVraagGroup("3. De extra opties op een Carver vind ik toereikend",      235, out rbN3, out rbNeu3, out rbM3);
        grpV4 = MaakVraagGroup("4. Ik ga snel over tot aanschaf van een Carver",           315, out rbN4, out rbNeu4, out rbM4);

        btnOpslaan.Text = "Opslaan";
        btnOpslaan.Location = new Point(395, 410);
        btnOpslaan.Size = new Size(85, 32);
        btnOpslaan.BackColor = Color.PaleGreen;
        btnOpslaan.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;
        btnOpslaan.Click += btnOpslaan_Click;

        btnAnnuleren.Text = "Annuleren";
        btnAnnuleren.Location = new Point(485, 410);
        btnAnnuleren.Size = new Size(90, 32);
        btnAnnuleren.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;
        btnAnnuleren.Click += btnAnnuleren_Click;

        AutoScaleDimensions = new SizeF(7F, 15F);
        AutoScaleMode = AutoScaleMode.Font;
        ClientSize = new Size(590, 455);
        MinimumSize = new Size(600, 485);
        Controls.AddRange(new Control[] {
            lblTitel, lblContext, grpV1, grpV2, grpV3, grpV4,
            btnOpslaan, btnAnnuleren
        });
        StartPosition = FormStartPosition.CenterParent;
        Text = "Ervaring vastleggen";
        ResumeLayout(false);
    }
}
