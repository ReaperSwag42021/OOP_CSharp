using CarverApp.Repositories;

namespace CarverApp.Forms;

public partial class FrmStatistieken : Form
{
    private readonly ErvaringRepository _repo = new();
    private Dictionary<int, Dictionary<int, int>> _data = new();

    private static readonly string[] VraagTitels = new[]
    {
        "1. Rijden voldoet aan verwachting",
        "2. Prijsstelling is naar wens",
        "3. Extra opties zijn toereikend",
        "4. Gaat snel over tot aanschaf"
    };

    public FrmStatistieken()
    {
        InitializeComponent();
        Verversen();
    }

    private void Verversen()
    {
        _data = _repo.StatistiekenPerVraag();
        int totaal = _data[1].Values.Sum();
        lblTotaal.Text = totaal == 0
            ? "Nog geen ervaringen vastgelegd."
            : $"Totaal ingevulde ervaringen: {totaal}";
        panelChart.Invalidate();
    }

    private void panelChart_Paint(object? sender, PaintEventArgs e)
    {
        var g = e.Graphics;
        g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
        g.TextRenderingHint = System.Drawing.Text.TextRenderingHint.ClearTypeGridFit;

        int padding = 20;
        int areaW = panelChart.ClientSize.Width  - 2 * padding;
        int areaH = panelChart.ClientSize.Height - 2 * padding;
        if (areaW < 100 || areaH < 100) return;

        // 4 vragen onder elkaar, elke "groep" heeft 3 staven (Niet mee eens / Neutraal / Mee eens)
        int groupH = areaH / 4;
        int barH = (groupH - 50) / 3;
        if (barH < 8) barH = 8;

        using var fontTitle = new Font("Segoe UI", 9.5F, FontStyle.Bold);
        using var fontLabel = new Font("Segoe UI", 9F);
        using var penAxis   = new Pen(Color.Gray);

        // Bepaal max voor schaal
        int max = 1;
        foreach (var v in _data.Values)
            foreach (var c in v.Values)
                if (c > max) max = c;

        Color[] kleuren = { Color.IndianRed, Color.Goldenrod, Color.MediumSeaGreen };
        string[] labels = { "Niet mee eens", "Neutraal", "Mee eens" };

        for (int q = 1; q <= 4; q++)
        {
            int gy = padding + (q - 1) * groupH;
            // Titel
            g.DrawString(VraagTitels[q - 1], fontTitle, Brushes.Black, padding, gy);

            int barStart = padding + 150;
            int chartW = areaW - 150 - 60;
            for (int a = 1; a <= 3; a++)
            {
                int by = gy + 22 + (a - 1) * (barH + 4);
                int count = _data[q][a];
                int width = (int)((double)count / max * chartW);

                // Label links
                g.DrawString(labels[a - 1], fontLabel, Brushes.Black, padding, by + (barH - 14) / 2);

                // Achtergrond
                g.FillRectangle(Brushes.WhiteSmoke, barStart, by, chartW, barH);

                // Bar
                using var brush = new SolidBrush(kleuren[a - 1]);
                g.FillRectangle(brush, barStart, by, width, barH);

                // Rand
                g.DrawRectangle(penAxis, barStart, by, chartW, barH);

                // Aantal achter de balk
                g.DrawString(count.ToString(), fontLabel, Brushes.Black,
                    barStart + width + 6, by + (barH - 14) / 2);
            }
        }
    }

    private void btnVerversen_Click(object? sender, EventArgs e) => Verversen();
    private void btnSluiten_Click(object? sender, EventArgs e) => Close();
}
