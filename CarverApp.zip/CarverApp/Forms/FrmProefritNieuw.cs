using CarverApp.Models;
using CarverApp.Repositories;

namespace CarverApp.Forms;

public partial class FrmProefritNieuw : Form
{
    private readonly CarverRepository _carverRepo = new();
    private readonly ProspectRepository _prospectRepo = new();
    private readonly ProefritRepository _proefritRepo = new();

    public FrmProefritNieuw()
    {
        InitializeComponent();
        LaadCarvers();
        dtpDatumTijd.Value = DateTime.Now.Date.AddDays(1).AddHours(10);
    }

    private void LaadCarvers()
    {
        var carvers = _carverRepo.OphalenAlle();
        cmbCarver.DisplayMember = nameof(Carver.Model);
        cmbCarver.ValueMember = nameof(Carver.Id);
        cmbCarver.DataSource = carvers;
    }

    private void btnOpslaan_Click(object? sender, EventArgs e)
    {
        if (!Valideer()) return;

        try
        {
            // 1. Prospect opslaan
            var prospect = new Prospect
            {
                Voornaam          = txtVoornaam.Text.Trim(),
                Achternaam        = txtAchternaam.Text.Trim(),
                Email             = LegeNull(txtEmail.Text),
                Telefoon          = LegeNull(txtTelefoon.Text),
                Adres             = LegeNull(txtAdres.Text),
                Postcode          = LegeNull(txtPostcode.Text),
                Woonplaats        = LegeNull(txtWoonplaats.Text),
                RijbewijsAB       = chkRijbewijsAB.Checked,
                RijbewijsAM       = chkRijbewijsAM.Checked,
                Invalidenvoertuig = chkInvalide.Checked,
                Motivatie         = LegeNull(txtMotivatie.Text),
            };
            int prospectId = _prospectRepo.Toevoegen(prospect);

            // 2. Proefrit opslaan
            var proefrit = new Proefrit
            {
                ProspectId  = prospectId,
                CarverId    = (int)cmbCarver.SelectedValue!,
                DatumTijd   = dtpDatumTijd.Value,
                Status      = ProefritStatus.Gepland,
                Bevestigd   = chkBevestigd.Checked,
                Opmerkingen = LegeNull(txtOpmerkingen.Text)
            };
            _proefritRepo.Toevoegen(proefrit);

            MessageBox.Show(this, "Proefrit succesvol geregistreerd.",
                "Opgeslagen", MessageBoxButtons.OK, MessageBoxIcon.Information);
            DialogResult = DialogResult.OK;
            Close();
        }
        catch (Exception ex)
        {
            MessageBox.Show(this, "Opslaan mislukt:\n" + ex.Message,
                "Fout", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }

    private bool Valideer()
    {
        if (string.IsNullOrWhiteSpace(txtVoornaam.Text) ||
            string.IsNullOrWhiteSpace(txtAchternaam.Text))
        {
            MessageBox.Show(this, "Voornaam en achternaam zijn verplicht.",
                "Validatie", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return false;
        }
        if (cmbCarver.SelectedItem is null)
        {
            MessageBox.Show(this, "Kies een Carver-model.",
                "Validatie", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return false;
        }
        if (dtpDatumTijd.Value < DateTime.Now.AddMinutes(-5))
        {
            MessageBox.Show(this, "Datum/tijd ligt in het verleden.",
                "Validatie", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return false;
        }
        return true;
    }

    private static string? LegeNull(string s) => string.IsNullOrWhiteSpace(s) ? null : s.Trim();

    private void btnAnnuleren_Click(object? sender, EventArgs e)
    {
        DialogResult = DialogResult.Cancel;
        Close();
    }
}
