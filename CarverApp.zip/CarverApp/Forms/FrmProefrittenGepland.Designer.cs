namespace CarverApp.Forms;

partial class FrmProefrittenGepland
{
    private System.ComponentModel.IContainer components = null!;
    private Label lblTitel = null!;
    private ListView lvProefritten = null!;
    private Button btnWijzigen = null!, btnAfronden = null!, btnVerversen = null!, btnSluiten = null!;
    private Label lblStatus = null!;

    protected override void Dispose(bool disposing)
    {
        if (disposing && (components != null)) components.Dispose();
        base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
        lblTitel = new Label();
        lvProefritten = new ListView();
        btnWijzigen = new Button();
        btnAfronden = new Button();
        btnVerversen = new Button();
        btnSluiten = new Button();
        lblStatus = new Label();
        SuspendLayout();

        lblTitel.Text = "Uit te voeren proefritten";
        lblTitel.Font = new Font("Segoe UI", 14F, FontStyle.Bold);
        lblTitel.Location = new Point(15, 10);
        lblTitel.Size = new Size(600, 30);

        lvProefritten.Location = new Point(15, 50);
        lvProefritten.Size = new Size(740, 380);
        lvProefritten.View = View.Details;
        lvProefritten.FullRowSelect = true;
        lvProefritten.GridLines = true;
        lvProefritten.MultiSelect = false;
        lvProefritten.HideSelection = false;
        lvProefritten.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
        lvProefritten.Columns.Add("Datum/tijd",  140);
        lvProefritten.Columns.Add("Prospect",    200);
        lvProefritten.Columns.Add("Carver",      120);
        lvProefritten.Columns.Add("Bevestigd",   80);
        lvProefritten.Columns.Add("Opmerkingen", 180);

        btnWijzigen.Text = "Wijzigen...";
        btnWijzigen.Location = new Point(15, 445);
        btnWijzigen.Size = new Size(100, 32);
        btnWijzigen.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
        btnWijzigen.Click += btnWijzigen_Click;

        btnAfronden.Text = "Markeer uitgevoerd";
        btnAfronden.Location = new Point(125, 445);
        btnAfronden.Size = new Size(150, 32);
        btnAfronden.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
        btnAfronden.Click += btnAfronden_Click;

        btnVerversen.Text = "Verversen";
        btnVerversen.Location = new Point(285, 445);
        btnVerversen.Size = new Size(100, 32);
        btnVerversen.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
        btnVerversen.Click += btnVerversen_Click;

        btnSluiten.Text = "Sluiten";
        btnSluiten.Location = new Point(660, 445);
        btnSluiten.Size = new Size(95, 32);
        btnSluiten.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;
        btnSluiten.Click += btnSluiten_Click;

        lblStatus.Location = new Point(15, 485);
        lblStatus.Size = new Size(600, 22);
        lblStatus.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
        lblStatus.ForeColor = Color.DimGray;

        AutoScaleDimensions = new SizeF(7F, 15F);
        AutoScaleMode = AutoScaleMode.Font;
        ClientSize = new Size(770, 515);
        MinimumSize = new Size(640, 400);
        Controls.AddRange(new Control[] {
            lblTitel, lvProefritten, btnWijzigen, btnAfronden, btnVerversen, btnSluiten, lblStatus
        });
        StartPosition = FormStartPosition.CenterParent;
        Text = "Geplande proefritten";
        ResumeLayout(false);
    }
}
