using CarverApp.Repositories;

namespace CarverApp.Forms;

public partial class FrmLogin : Form
{
    private readonly GebruikerRepository _repo = new();

    public FrmLogin()
    {
        InitializeComponent();
        AcceptButton = btnLogin;
        CancelButton = btnAnnuleren;
    }

    private void btnLogin_Click(object? sender, EventArgs e)
    {
        string naam = txtGebruikersnaam.Text.Trim();
        string wachtwoord = txtWachtwoord.Text;

        if (string.IsNullOrWhiteSpace(naam) || string.IsNullOrWhiteSpace(wachtwoord))
        {
            lblFout.Text = "Vul beide velden in.";
            return;
        }

        try
        {
            var gebruiker = _repo.ZoekOpGebruikersnaam(naam);
            if (gebruiker is null || !gebruiker.ControleerWachtwoord(wachtwoord))
            {
                lblFout.Text = "Onjuiste gebruikersnaam of wachtwoord.";
                txtWachtwoord.Clear();
                txtWachtwoord.Focus();
                return;
            }

            Program.HuidigeGebruiker = gebruiker;
            DialogResult = DialogResult.OK;
            Close();
        }
        catch (Exception ex)
        {
            lblFout.Text = "Database-fout: " + ex.Message;
        }
    }

    private void btnAnnuleren_Click(object? sender, EventArgs e)
    {
        DialogResult = DialogResult.Cancel;
        Close();
    }
}
