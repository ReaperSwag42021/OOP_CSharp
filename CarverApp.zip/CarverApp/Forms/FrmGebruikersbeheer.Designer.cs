namespace CarverApp.Forms;

partial class FrmGebruikersbeheer
{
    private System.ComponentModel.IContainer components = null!;
    private Label lblTitel = null!;
    private ListView lvGebruikers = null!;
    private Button btnToevoegen = null!, btnWijzigen = null!, btnVerwijderen = null!, btnSluiten = null!;
    private Label lblStatus = null!;

    protected override void Dispose(bool disposing)
    {
        if (disposing && (components != null)) components.Dispose();
        base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
        lblTitel = new Label();
        lvGebruikers = new ListView();
        btnToevoegen = new Button();
        btnWijzigen = new Button();
        btnVerwijderen = new Button();
        btnSluiten = new Button();
        lblStatus = new Label();
        SuspendLayout();

        lblTitel.Text = "Gebruikersbeheer";
        lblTitel.Font = new Font("Segoe UI", 14F, FontStyle.Bold);
        lblTitel.Location = new Point(15, 10);
        lblTitel.Size = new Size(560, 30);

        lvGebruikers.Location = new Point(15, 50);
        lvGebruikers.Size = new Size(610, 320);
        lvGebruikers.View = View.Details;
        lvGebruikers.FullRowSelect = true;
        lvGebruikers.GridLines = true;
        lvGebruikers.MultiSelect = false;
        lvGebruikers.HideSelection = false;
        lvGebruikers.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
        lvGebruikers.Columns.Add("Gebruikersnaam", 150);
        lvGebruikers.Columns.Add("Volledige naam", 200);
        lvGebruikers.Columns.Add("Admin",           70);
        lvGebruikers.Columns.Add("Aangemaakt op", 130);

        btnToevoegen.Text = "Toevoegen...";
        btnToevoegen.Location = new Point(15, 385);
        btnToevoegen.Size = new Size(110, 32);
        btnToevoegen.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
        btnToevoegen.Click += btnToevoegen_Click;

        btnWijzigen.Text = "Wijzigen...";
        btnWijzigen.Location = new Point(135, 385);
        btnWijzigen.Size = new Size(100, 32);
        btnWijzigen.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
        btnWijzigen.Click += btnWijzigen_Click;

        btnVerwijderen.Text = "Verwijderen";
        btnVerwijderen.Location = new Point(245, 385);
        btnVerwijderen.Size = new Size(110, 32);
        btnVerwijderen.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
        btnVerwijderen.BackColor = Color.MistyRose;
        btnVerwijderen.Click += btnVerwijderen_Click;

        btnSluiten.Text = "Sluiten";
        btnSluiten.Location = new Point(530, 385);
        btnSluiten.Size = new Size(95, 32);
        btnSluiten.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;
        btnSluiten.Click += btnSluiten_Click;

        lblStatus.Location = new Point(15, 425);
        lblStatus.Size = new Size(400, 22);
        lblStatus.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
        lblStatus.ForeColor = Color.DimGray;

        AutoScaleDimensions = new SizeF(7F, 15F);
        AutoScaleMode = AutoScaleMode.Font;
        ClientSize = new Size(640, 455);
        MinimumSize = new Size(560, 400);
        Controls.AddRange(new Control[] {
            lblTitel, lvGebruikers, btnToevoegen, btnWijzigen, btnVerwijderen, btnSluiten, lblStatus
        });
        StartPosition = FormStartPosition.CenterParent;
        Text = "Gebruikersbeheer";
        ResumeLayout(false);
    }
}
