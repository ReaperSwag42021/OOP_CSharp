namespace CarverApp.Forms;

partial class FrmStatistieken
{
    private System.ComponentModel.IContainer components = null!;
    private Label lblTitel = null!, lblTotaal = null!;
    private Panel panelChart = null!;
    private Button btnVerversen = null!, btnSluiten = null!;

    protected override void Dispose(bool disposing)
    {
        if (disposing && (components != null)) components.Dispose();
        base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
        lblTitel = new Label();
        lblTotaal = new Label();
        panelChart = new Panel();
        btnVerversen = new Button();
        btnSluiten = new Button();
        SuspendLayout();

        lblTitel.Text = "Statistieken - Gebruikerservaring";
        lblTitel.Font = new Font("Segoe UI", 14F, FontStyle.Bold);
        lblTitel.Location = new Point(15, 10);
        lblTitel.Size = new Size(600, 30);

        lblTotaal.Location = new Point(15, 42);
        lblTotaal.Size = new Size(600, 22);
        lblTotaal.Font = new Font("Segoe UI", 9.5F, FontStyle.Italic);
        lblTotaal.ForeColor = Color.DimGray;

        panelChart.Location = new Point(15, 75);
        panelChart.Size = new Size(740, 450);
        panelChart.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
        panelChart.BorderStyle = BorderStyle.FixedSingle;
        panelChart.BackColor = Color.White;
        panelChart.Paint += panelChart_Paint;

        btnVerversen.Text = "Verversen";
        btnVerversen.Location = new Point(15, 540);
        btnVerversen.Size = new Size(100, 32);
        btnVerversen.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
        btnVerversen.Click += btnVerversen_Click;

        btnSluiten.Text = "Sluiten";
        btnSluiten.Location = new Point(660, 540);
        btnSluiten.Size = new Size(95, 32);
        btnSluiten.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;
        btnSluiten.Click += btnSluiten_Click;

        AutoScaleDimensions = new SizeF(7F, 15F);
        AutoScaleMode = AutoScaleMode.Font;
        ClientSize = new Size(770, 590);
        MinimumSize = new Size(640, 500);
        Controls.AddRange(new Control[] {
            lblTitel, lblTotaal, panelChart, btnVerversen, btnSluiten
        });
        StartPosition = FormStartPosition.CenterParent;
        Text = "Statistieken";
        ResumeLayout(false);
    }
}
