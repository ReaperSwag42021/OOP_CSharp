using CarverApp.Models;
using CarverApp.Repositories;

namespace CarverApp.Forms;

public partial class FrmGebruikersbeheer : Form
{
    private readonly GebruikerRepository _repo = new();

    public FrmGebruikersbeheer()
    {
        InitializeComponent();
        Verversen();
    }

    private void Verversen()
    {
        var lijst = _repo.OphalenAlle();
        lvGebruikers.Items.Clear();
        foreach (var g in lijst)
        {
            var item = new ListViewItem(g.Gebruikersnaam) { Tag = g };
            item.SubItems.Add(g.VolledigeNaam);
            item.SubItems.Add(g.IsAdmin ? "Ja" : "Nee");
            item.SubItems.Add(g.AangemaaktOp.ToString("dd-MM-yyyy"));
            lvGebruikers.Items.Add(item);
        }
        lblStatus.Text = $"{lijst.Count} gebruiker(s)";
    }

    private Gebruiker? Geselecteerd()
        => lvGebruikers.SelectedItems.Count == 0
            ? null
            : (Gebruiker)lvGebruikers.SelectedItems[0].Tag!;

    private void btnToevoegen_Click(object? sender, EventArgs e)
    {
        using var dlg = new FrmGebruikerEdit(null);
        if (dlg.ShowDialog(this) == DialogResult.OK)
        {
            try
            {
                _repo.Toevoegen(dlg.Gebruikersnaam, dlg.Wachtwoord, dlg.VolledigeNaam, dlg.IsAdmin);
                Verversen();
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, "Toevoegen mislukt:\n" + ex.Message,
                    "Fout", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }

    private void btnWijzigen_Click(object? sender, EventArgs e)
    {
        var g = Geselecteerd();
        if (g is null) return;

        using var dlg = new FrmGebruikerEdit(g);
        if (dlg.ShowDialog(this) == DialogResult.OK)
        {
            try
            {
                _repo.Wijzigen(g.Id, dlg.VolledigeNaam, dlg.IsAdmin);
                if (!string.IsNullOrEmpty(dlg.Wachtwoord))
                    _repo.WijzigWachtwoord(g.Id, dlg.Wachtwoord);
                Verversen();
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, "Wijzigen mislukt:\n" + ex.Message,
                    "Fout", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }

    private void btnVerwijderen_Click(object? sender, EventArgs e)
    {
        var g = Geselecteerd();
        if (g is null) return;
        if (g.Id == Program.HuidigeGebruiker?.Id)
        {
            MessageBox.Show(this, "Je kunt jezelf niet verwijderen.",
                "Niet toegestaan", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return;
        }

        var res = MessageBox.Show(this,
            $"Weet je zeker dat je gebruiker '{g.Gebruikersnaam}' wilt verwijderen?",
            "Bevestigen", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
        if (res != DialogResult.Yes) return;

        try
        {
            _repo.Verwijderen(g.Id);
            Verversen();
        }
        catch (Exception ex)
        {
            MessageBox.Show(this, "Verwijderen mislukt:\n" + ex.Message,
                "Fout", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }

    private void btnSluiten_Click(object? sender, EventArgs e) => Close();
}
