namespace CarverApp.Forms;

partial class FrmGebruikerEdit
{
    private System.ComponentModel.IContainer components = null!;
    private Label lblTitel = null!;
    private Label lblGebruikersnaam = null!;
    private Label lblVolledigeNaam = null!;
    private Label lblWachtwoord = null!;
    private TextBox txtGebruikersnaam = null!;
    private TextBox txtVolledigeNaam = null!;
    private TextBox txtWachtwoord = null!;
    private CheckBox chkAdmin = null!;
    private Label lblFout = null!;
    private Button btnOK = null!;
    private Button btnAnnuleren = null!;

    protected override void Dispose(bool disposing)
    {
        if (disposing && (components != null))
            components.Dispose();
        base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
        lblTitel = new Label();
        lblGebruikersnaam = new Label();
        lblVolledigeNaam = new Label();
        lblWachtwoord = new Label();
        txtGebruikersnaam = new TextBox();
        txtVolledigeNaam = new TextBox();
        txtWachtwoord = new TextBox();
        chkAdmin = new CheckBox();
        lblFout = new Label();
        btnOK = new Button();
        btnAnnuleren = new Button();
        SuspendLayout();

        // lblTitel
        lblTitel.AutoSize = false;
        lblTitel.Font = new Font("Segoe UI", 14F, FontStyle.Bold);
        lblTitel.Location = new Point(20, 15);
        lblTitel.Size = new Size(400, 32);
        lblTitel.Text = "Gebruiker";
        lblTitel.TextAlign = ContentAlignment.MiddleLeft;

        // lblGebruikersnaam
        lblGebruikersnaam.Location = new Point(20, 65);
        lblGebruikersnaam.Size = new Size(150, 23);
        lblGebruikersnaam.Text = "Gebruikersnaam: *";
        lblGebruikersnaam.TextAlign = ContentAlignment.MiddleLeft;

        // txtGebruikersnaam
        txtGebruikersnaam.Location = new Point(180, 65);
        txtGebruikersnaam.Size = new Size(230, 23);

        // lblVolledigeNaam
        lblVolledigeNaam.Location = new Point(20, 100);
        lblVolledigeNaam.Size = new Size(150, 23);
        lblVolledigeNaam.Text = "Volledige naam: *";
        lblVolledigeNaam.TextAlign = ContentAlignment.MiddleLeft;

        // txtVolledigeNaam
        txtVolledigeNaam.Location = new Point(180, 100);
        txtVolledigeNaam.Size = new Size(230, 23);

        // lblWachtwoord
        lblWachtwoord.Location = new Point(20, 135);
        lblWachtwoord.Size = new Size(150, 23);
        lblWachtwoord.Text = "Wachtwoord:";
        lblWachtwoord.TextAlign = ContentAlignment.MiddleLeft;

        // txtWachtwoord
        txtWachtwoord.Location = new Point(180, 135);
        txtWachtwoord.Size = new Size(230, 23);
        txtWachtwoord.UseSystemPasswordChar = true;

        // chkAdmin
        chkAdmin.Location = new Point(180, 170);
        chkAdmin.Size = new Size(230, 25);
        chkAdmin.Text = "Administrator";
        chkAdmin.UseVisualStyleBackColor = true;

        // lblFout
        lblFout.ForeColor = Color.Firebrick;
        lblFout.Location = new Point(20, 205);
        lblFout.Size = new Size(395, 35);
        lblFout.Text = "";

        // btnOK
        btnOK.Location = new Point(230, 250);
        btnOK.Size = new Size(85, 32);
        btnOK.Text = "OK";
        btnOK.UseVisualStyleBackColor = true;
        btnOK.Click += btnOK_Click;

        // btnAnnuleren
        btnAnnuleren.Location = new Point(325, 250);
        btnAnnuleren.Size = new Size(85, 32);
        btnAnnuleren.Text = "Annuleren";
        btnAnnuleren.UseVisualStyleBackColor = true;
        btnAnnuleren.Click += btnAnnuleren_Click;

        // FrmGebruikerEdit
        AutoScaleDimensions = new SizeF(7F, 15F);
        AutoScaleMode = AutoScaleMode.Font;
        AcceptButton = btnOK;
        CancelButton = btnAnnuleren;
        ClientSize = new Size(434, 300);
        Controls.Add(lblTitel);
        Controls.Add(lblGebruikersnaam);
        Controls.Add(txtGebruikersnaam);
        Controls.Add(lblVolledigeNaam);
        Controls.Add(txtVolledigeNaam);
        Controls.Add(lblWachtwoord);
        Controls.Add(txtWachtwoord);
        Controls.Add(chkAdmin);
        Controls.Add(lblFout);
        Controls.Add(btnOK);
        Controls.Add(btnAnnuleren);
        FormBorderStyle = FormBorderStyle.FixedDialog;
        MaximizeBox = false;
        MinimizeBox = false;
        StartPosition = FormStartPosition.CenterParent;
        Text = "Gebruiker";
        ResumeLayout(false);
    }
}
