using CarverApp.Models;

namespace CarverApp.Forms;

public partial class FrmGebruikerEdit : Form
{
    private readonly Gebruiker? _bestaand;

    public string Gebruikersnaam => txtGebruikersnaam.Text.Trim();
    public string Wachtwoord     => txtWachtwoord.Text;
    public string VolledigeNaam  => txtVolledigeNaam.Text.Trim();
    public bool IsAdmin          => chkAdmin.Checked;

    /// <param name="bestaand">null = nieuw aanmaken, anders bewerken</param>
    public FrmGebruikerEdit(Gebruiker? bestaand)
    {
        _bestaand = bestaand;
        InitializeComponent();

        if (bestaand is null)
        {
            Text = "Gebruiker toevoegen";
            lblTitel.Text = "Nieuwe gebruiker";
            lblWachtwoord.Text = "Wachtwoord: *";
        }
        else
        {
            Text = "Gebruiker wijzigen";
            lblTitel.Text = $"Wijzigen: {bestaand.Gebruikersnaam}";
            txtGebruikersnaam.Text = bestaand.Gebruikersnaam;
            txtGebruikersnaam.ReadOnly = true;
            txtVolledigeNaam.Text = bestaand.VolledigeNaam;
            chkAdmin.Checked = bestaand.IsAdmin;
            lblWachtwoord.Text = "Nieuw wachtwoord (leeg = ongewijzigd):";
        }
    }

    private void btnOK_Click(object? sender, EventArgs e)
    {
        if (string.IsNullOrWhiteSpace(Gebruikersnaam))
        {
            Fout("Gebruikersnaam is verplicht.");
            return;
        }
        if (string.IsNullOrWhiteSpace(VolledigeNaam))
        {
            Fout("Volledige naam is verplicht.");
            return;
        }
        if (_bestaand is null && string.IsNullOrWhiteSpace(Wachtwoord))
        {
            Fout("Wachtwoord is verplicht voor een nieuwe gebruiker.");
            return;
        }
        if (!string.IsNullOrWhiteSpace(Wachtwoord) && Wachtwoord.Length < 4)
        {
            Fout("Wachtwoord moet minimaal 4 tekens lang zijn.");
            return;
        }

        DialogResult = DialogResult.OK;
        Close();
    }

    private void Fout(string tekst)
    {
        lblFout.Text = tekst;
    }

    private void btnAnnuleren_Click(object? sender, EventArgs e)
    {
        DialogResult = DialogResult.Cancel;
        Close();
    }
}
