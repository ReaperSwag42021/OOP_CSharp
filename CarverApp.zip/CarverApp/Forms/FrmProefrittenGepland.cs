using CarverApp.Models;
using CarverApp.Repositories;

namespace CarverApp.Forms;

public partial class FrmProefrittenGepland : Form
{
    private readonly ProefritRepository _repo = new();

    public FrmProefrittenGepland()
    {
        InitializeComponent();
        VerversLijst();
    }

    private void VerversLijst()
    {
        var lijst = _repo.OphalenOpStatus(ProefritStatus.Gepland);

        lvProefritten.Items.Clear();
        foreach (var pr in lijst)
        {
            var item = new ListViewItem(pr.DatumTijd.ToString("dd-MM-yyyy HH:mm"))
            {
                Tag = pr
            };
            item.SubItems.Add(pr.Prospect?.VolledigeNaam ?? "");
            item.SubItems.Add(pr.Carver?.Model ?? "");
            item.SubItems.Add(pr.Bevestigd ? "Ja" : "Nee");
            item.SubItems.Add(pr.Opmerkingen ?? "");
            lvProefritten.Items.Add(item);
        }
        lblStatus.Text = $"{lijst.Count} geplande proefrit(ten)";
    }

    private Proefrit? GeselecteerdeProefrit()
        => lvProefritten.SelectedItems.Count == 0
            ? null
            : (Proefrit)lvProefritten.SelectedItems[0].Tag!;

    private void btnWijzigen_Click(object? sender, EventArgs e)
    {
        var pr = GeselecteerdeProefrit();
        if (pr is null)
        {
            MessageBox.Show(this, "Selecteer eerst een proefrit.", "Geen selectie",
                MessageBoxButtons.OK, MessageBoxIcon.Information);
            return;
        }

        using var f = new FrmProefritWijzigen(pr);
        if (f.ShowDialog(this) == DialogResult.OK)
            VerversLijst();
    }

    private void btnAfronden_Click(object? sender, EventArgs e)
    {
        var pr = GeselecteerdeProefrit();
        if (pr is null) return;

        var res = MessageBox.Show(this,
            "Weet je zeker dat je deze proefrit op 'Uitgevoerd' wilt zetten?",
            "Bevestigen", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
        if (res != DialogResult.Yes) return;

        _repo.Afronden(pr.Id);
        VerversLijst();
    }

    private void btnVerversen_Click(object? sender, EventArgs e) => VerversLijst();

    private void btnSluiten_Click(object? sender, EventArgs e) => Close();
}
