using CarverApp.Models;
using CarverApp.Repositories;

namespace CarverApp.Forms;

public partial class FrmProefritWijzigen : Form
{
    private readonly Proefrit _proefrit;
    private readonly Prospect _prospect;
    private readonly ProefritRepository _proefritRepo = new();
    private readonly ProspectRepository _prospectRepo = new();
    private readonly CarverRepository _carverRepo = new();

    public FrmProefritWijzigen(Proefrit proefrit)
    {
        _proefrit = proefrit ?? throw new ArgumentNullException(nameof(proefrit));
        _prospect = _prospectRepo.OphalenOpId(proefrit.ProspectId)
                    ?? throw new InvalidOperationException("Prospect niet gevonden.");
        InitializeComponent();
        LaadGegevens();
    }

    private void LaadGegevens()
    {
        // Prospect-velden
        txtVoornaam.Text     = _prospect.Voornaam;
        txtAchternaam.Text   = _prospect.Achternaam;
        txtEmail.Text        = _prospect.Email ?? "";
        txtTelefoon.Text     = _prospect.Telefoon ?? "";
        txtAdres.Text        = _prospect.Adres ?? "";
        txtPostcode.Text     = _prospect.Postcode ?? "";
        txtWoonplaats.Text   = _prospect.Woonplaats ?? "";
        chkRijbewijsAB.Checked = _prospect.RijbewijsAB;
        chkRijbewijsAM.Checked = _prospect.RijbewijsAM;
        chkInvalide.Checked    = _prospect.Invalidenvoertuig;
        txtMotivatie.Text    = _prospect.Motivatie ?? "";

        // Carvers
        var carvers = _carverRepo.OphalenAlle();
        cmbCarver.DisplayMember = nameof(Carver.Model);
        cmbCarver.ValueMember = nameof(Carver.Id);
        cmbCarver.DataSource = carvers;
        cmbCarver.SelectedValue = _proefrit.CarverId;

        dtpDatumTijd.Value = _proefrit.DatumTijd;
        chkBevestigd.Checked = _proefrit.Bevestigd;
        txtOpmerkingen.Text = _proefrit.Opmerkingen ?? "";

        btnExportPdf.Visible = true;
    }

    private void btnOpslaan_Click(object? sender, EventArgs e)
    {
        if (string.IsNullOrWhiteSpace(txtVoornaam.Text) ||
            string.IsNullOrWhiteSpace(txtAchternaam.Text))
        {
            MessageBox.Show(this, "Voornaam en achternaam zijn verplicht.",
                "Validatie", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return;
        }

        try
        {
            _prospect.Voornaam          = txtVoornaam.Text.Trim();
            _prospect.Achternaam        = txtAchternaam.Text.Trim();
            _prospect.Email             = NullIfEmpty(txtEmail.Text);
            _prospect.Telefoon          = NullIfEmpty(txtTelefoon.Text);
            _prospect.Adres             = NullIfEmpty(txtAdres.Text);
            _prospect.Postcode          = NullIfEmpty(txtPostcode.Text);
            _prospect.Woonplaats        = NullIfEmpty(txtWoonplaats.Text);
            _prospect.RijbewijsAB       = chkRijbewijsAB.Checked;
            _prospect.RijbewijsAM       = chkRijbewijsAM.Checked;
            _prospect.Invalidenvoertuig = chkInvalide.Checked;
            _prospect.Motivatie         = NullIfEmpty(txtMotivatie.Text);
            _prospectRepo.Wijzigen(_prospect);

            _proefrit.CarverId    = (int)cmbCarver.SelectedValue!;
            _proefrit.DatumTijd   = dtpDatumTijd.Value;
            _proefrit.Bevestigd   = chkBevestigd.Checked;
            _proefrit.Opmerkingen = NullIfEmpty(txtOpmerkingen.Text);
            _proefritRepo.Wijzigen(_proefrit);

            DialogResult = DialogResult.OK;
            Close();
        }
        catch (Exception ex)
        {
            MessageBox.Show(this, "Wijzigen mislukt:\n" + ex.Message,
                "Fout", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }

    private void btnExportPdf_Click(object? sender, EventArgs e)
    {
        try
        {
            using var sfd = new SaveFileDialog
            {
                Filter = "PDF (*.pdf)|*.pdf",
                FileName = $"Klantenkaart_{_prospect.Achternaam}_{DateTime.Now:yyyyMMdd}.pdf"
            };
            if (sfd.ShowDialog(this) != DialogResult.OK) return;

            var alle = new[] { ProefritStatus.Gepland, ProefritStatus.Uitgevoerd }
                .SelectMany(s => _proefritRepo.OphalenOpStatus(s))
                .Where(p => p.ProspectId == _prospect.Id)
                .ToList();

            Helpers.PdfExporter.ExporteerKlantenkaart(_prospect, alle, sfd.FileName);
            MessageBox.Show(this, $"Klantenkaart opgeslagen:\n{sfd.FileName}",
                "Export gelukt", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
        catch (Exception ex)
        {
            MessageBox.Show(this, "Export mislukt:\n" + ex.Message,
                "Fout", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }

    private static string? NullIfEmpty(string s) => string.IsNullOrWhiteSpace(s) ? null : s.Trim();

    private void btnAnnuleren_Click(object? sender, EventArgs e)
    {
        DialogResult = DialogResult.Cancel;
        Close();
    }
}
