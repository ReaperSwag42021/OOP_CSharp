namespace CarverApp.Forms;

partial class FrmProefritNieuw
{
    private System.ComponentModel.IContainer components = null!;
    private Label lblTitel = null!;

    // Prospect-velden
    private GroupBox grpProspect = null!;
    private Label lblVoornaam = null!, lblAchternaam = null!, lblEmail = null!, lblTelefoon = null!;
    private Label lblAdres = null!, lblPostcode = null!, lblWoonplaats = null!;
    private TextBox txtVoornaam = null!, txtAchternaam = null!, txtEmail = null!, txtTelefoon = null!;
    private TextBox txtAdres = null!, txtPostcode = null!, txtWoonplaats = null!;
    private CheckBox chkRijbewijsAB = null!, chkRijbewijsAM = null!, chkInvalide = null!;
    private Label lblMotivatie = null!;
    private TextBox txtMotivatie = null!;

    // Proefrit-velden
    private GroupBox grpProefrit = null!;
    private Label lblCarver = null!, lblDatumTijd = null!, lblOpmerkingen = null!;
    private ComboBox cmbCarver = null!;
    private DateTimePicker dtpDatumTijd = null!;
    private CheckBox chkBevestigd = null!;
    private TextBox txtOpmerkingen = null!;

    private Button btnOpslaan = null!, btnAnnuleren = null!;

    protected override void Dispose(bool disposing)
    {
        if (disposing && (components != null)) components.Dispose();
        base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
        lblTitel = new Label();
        grpProspect = new GroupBox();
        grpProefrit = new GroupBox();
        lblVoornaam = new Label(); lblAchternaam = new Label();
        lblEmail = new Label(); lblTelefoon = new Label();
        lblAdres = new Label(); lblPostcode = new Label(); lblWoonplaats = new Label();
        txtVoornaam = new TextBox(); txtAchternaam = new TextBox();
        txtEmail = new TextBox(); txtTelefoon = new TextBox();
        txtAdres = new TextBox(); txtPostcode = new TextBox(); txtWoonplaats = new TextBox();
        chkRijbewijsAB = new CheckBox(); chkRijbewijsAM = new CheckBox(); chkInvalide = new CheckBox();
        lblMotivatie = new Label(); txtMotivatie = new TextBox();
        lblCarver = new Label(); lblDatumTijd = new Label(); lblOpmerkingen = new Label();
        cmbCarver = new ComboBox(); dtpDatumTijd = new DateTimePicker();
        chkBevestigd = new CheckBox(); txtOpmerkingen = new TextBox();
        btnOpslaan = new Button(); btnAnnuleren = new Button();
        SuspendLayout();

        // ---- Titel ----
        lblTitel.Font = new Font("Segoe UI", 14F, FontStyle.Bold);
        lblTitel.Location = new Point(15, 10);
        lblTitel.Size = new Size(640, 30);
        lblTitel.Text = "Nieuwe proefrit registreren";

        // ---- GroupBox Prospect ----
        grpProspect.Text = "Prospect-gegevens";
        grpProspect.Location = new Point(15, 50);
        grpProspect.Size = new Size(640, 340);
        grpProspect.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
        grpProspect.Font = new Font("Segoe UI", 9F, FontStyle.Bold);

        // labels + textboxes
        void Label(Label lbl, string t, int x, int y) { lbl.Text = t; lbl.Location = new Point(x, y); lbl.Size = new Size(95, 22); lbl.Font = new Font("Segoe UI", 9F); }
        void Box(TextBox b, int x, int y, int w) { b.Location = new Point(x, y); b.Size = new Size(w, 23); b.Font = new Font("Segoe UI", 9F); }

        Label(lblVoornaam,   "Voornaam *",   15, 30);  Box(txtVoornaam,   115, 27, 180);
        Label(lblAchternaam, "Achternaam *", 310, 30); Box(txtAchternaam, 410, 27, 200);
        Label(lblEmail,      "Email",        15, 60);  Box(txtEmail,      115, 57, 180);
        Label(lblTelefoon,   "Telefoon",     310, 60); Box(txtTelefoon,   410, 57, 200);
        Label(lblAdres,      "Adres",        15, 90);  Box(txtAdres,      115, 87, 180);
        Label(lblPostcode,   "Postcode",     310, 90); Box(txtPostcode,   410, 87, 90);
        Label(lblWoonplaats, "Woonplaats",   510, 90); txtWoonplaats.Location = new Point(510, 87); txtWoonplaats.Size = new Size(100, 23);
        // (Woonplaats fix - position it on its own line)
        Label(lblWoonplaats, "Woonplaats",   15, 120);
        Box(txtWoonplaats,                  115, 117, 180);

        chkRijbewijsAB.Text = "Rijbewijs A of B";
        chkRijbewijsAB.Location = new Point(310, 117);
        chkRijbewijsAB.Size = new Size(140, 22);
        chkRijbewijsAB.Font = new Font("Segoe UI", 9F);

        chkRijbewijsAM.Text = "Rijbewijs AM (scooter)";
        chkRijbewijsAM.Location = new Point(310, 140);
        chkRijbewijsAM.Size = new Size(180, 22);
        chkRijbewijsAM.Font = new Font("Segoe UI", 9F);

        chkInvalide.Text = "Aanschaf als invalidenvoertuig";
        chkInvalide.Location = new Point(310, 163);
        chkInvalide.Size = new Size(220, 22);
        chkInvalide.Font = new Font("Segoe UI", 9F);

        Label(lblMotivatie, "Motivatie / interesse", 15, 195);
        lblMotivatie.Size = new Size(160, 22);
        txtMotivatie.Location = new Point(15, 220);
        txtMotivatie.Size = new Size(610, 100);
        txtMotivatie.Multiline = true;
        txtMotivatie.ScrollBars = ScrollBars.Vertical;
        txtMotivatie.Font = new Font("Segoe UI", 9F);
        txtMotivatie.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;

        grpProspect.Controls.AddRange(new Control[] {
            lblVoornaam, txtVoornaam, lblAchternaam, txtAchternaam,
            lblEmail, txtEmail, lblTelefoon, txtTelefoon,
            lblAdres, txtAdres, lblPostcode, txtPostcode,
            lblWoonplaats, txtWoonplaats,
            chkRijbewijsAB, chkRijbewijsAM, chkInvalide,
            lblMotivatie, txtMotivatie
        });

        // ---- GroupBox Proefrit ----
        grpProefrit.Text = "Proefrit-gegevens";
        grpProefrit.Location = new Point(15, 400);
        grpProefrit.Size = new Size(640, 180);
        grpProefrit.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
        grpProefrit.Font = new Font("Segoe UI", 9F, FontStyle.Bold);

        Label(lblCarver,     "Carver-model *", 15, 30);
        cmbCarver.Location = new Point(115, 27);
        cmbCarver.Size = new Size(280, 23);
        cmbCarver.Font = new Font("Segoe UI", 9F);
        cmbCarver.DropDownStyle = ComboBoxStyle.DropDownList;

        Label(lblDatumTijd, "Datum/tijd *", 15, 60);
        dtpDatumTijd.Location = new Point(115, 57);
        dtpDatumTijd.Size = new Size(200, 23);
        dtpDatumTijd.Font = new Font("Segoe UI", 9F);
        dtpDatumTijd.Format = DateTimePickerFormat.Custom;
        dtpDatumTijd.CustomFormat = "dd-MM-yyyy HH:mm";
        dtpDatumTijd.ShowUpDown = true;

        chkBevestigd.Text = "Telefonisch bevestigd";
        chkBevestigd.Location = new Point(335, 60);
        chkBevestigd.Size = new Size(200, 22);
        chkBevestigd.Font = new Font("Segoe UI", 9F);

        Label(lblOpmerkingen, "Opmerkingen", 15, 90);
        txtOpmerkingen.Location = new Point(115, 87);
        txtOpmerkingen.Size = new Size(510, 75);
        txtOpmerkingen.Multiline = true;
        txtOpmerkingen.ScrollBars = ScrollBars.Vertical;
        txtOpmerkingen.Font = new Font("Segoe UI", 9F);
        txtOpmerkingen.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;

        grpProefrit.Controls.AddRange(new Control[] {
            lblCarver, cmbCarver, lblDatumTijd, dtpDatumTijd,
            chkBevestigd, lblOpmerkingen, txtOpmerkingen
        });

        // ---- Knoppen ----
        btnOpslaan.Text = "Opslaan";
        btnOpslaan.Location = new Point(465, 595);
        btnOpslaan.Size = new Size(90, 32);
        btnOpslaan.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;
        btnOpslaan.BackColor = Color.PaleGreen;
        btnOpslaan.Click += btnOpslaan_Click;

        btnAnnuleren.Text = "Annuleren";
        btnAnnuleren.Location = new Point(565, 595);
        btnAnnuleren.Size = new Size(90, 32);
        btnAnnuleren.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;
        btnAnnuleren.Click += btnAnnuleren_Click;

        // ---- Form ----
        AutoScaleDimensions = new SizeF(7F, 15F);
        AutoScaleMode = AutoScaleMode.Font;
        ClientSize = new Size(670, 640);
        MinimumSize = new Size(680, 670);
        Controls.AddRange(new Control[] { lblTitel, grpProspect, grpProefrit, btnOpslaan, btnAnnuleren });
        StartPosition = FormStartPosition.CenterParent;
        Text = "Nieuwe proefrit";
        ResumeLayout(false);
    }
}
