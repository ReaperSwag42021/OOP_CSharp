using CarverApp.Models;
using CarverApp.Repositories;

namespace CarverApp.Forms;

public partial class FrmProefrittenUitgevoerd : Form
{
    private readonly ProefritRepository _proefritRepo = new();
    private readonly ErvaringRepository _ervaringRepo = new();

    public FrmProefrittenUitgevoerd()
    {
        InitializeComponent();
        VerversLijst();
    }

    private void VerversLijst()
    {
        var lijst = _proefritRepo.OphalenOpStatus(ProefritStatus.Uitgevoerd);

        lvProefritten.Items.Clear();
        foreach (var pr in lijst)
        {
            var ervaring = _ervaringRepo.OphalenOpProefrit(pr.Id);
            var item = new ListViewItem(pr.DatumTijd.ToString("dd-MM-yyyy HH:mm"))
            {
                Tag = pr
            };
            item.SubItems.Add(pr.Prospect?.VolledigeNaam ?? "");
            item.SubItems.Add(pr.Carver?.Model ?? "");
            item.SubItems.Add(ervaring is null ? "Nee" : "Ja");
            item.SubItems.Add(ervaring is null ? "-" : $"{ervaring.Gemiddelde:F2}");
            lvProefritten.Items.Add(item);
        }
        lblStatus.Text = $"{lijst.Count} uitgevoerde proefrit(ten)";
    }

    private Proefrit? Geselecteerd()
        => lvProefritten.SelectedItems.Count == 0
            ? null
            : (Proefrit)lvProefritten.SelectedItems[0].Tag!;

    private void btnErvaring_Click(object? sender, EventArgs e)
    {
        var pr = Geselecteerd();
        if (pr is null)
        {
            MessageBox.Show(this, "Selecteer eerst een proefrit.", "Geen selectie",
                MessageBoxButtons.OK, MessageBoxIcon.Information);
            return;
        }

        var bestaande = _ervaringRepo.OphalenOpProefrit(pr.Id);
        if (bestaande is not null)
        {
            MessageBox.Show(this, "Voor deze proefrit is al een ervaring vastgelegd.",
                "Al ingevuld", MessageBoxButtons.OK, MessageBoxIcon.Information);
            return;
        }

        using var f = new FrmErvaring(pr);
        if (f.ShowDialog(this) == DialogResult.OK)
            VerversLijst();
    }

    private void btnVerversen_Click(object? sender, EventArgs e) => VerversLijst();
    private void btnSluiten_Click(object? sender, EventArgs e) => Close();
}
