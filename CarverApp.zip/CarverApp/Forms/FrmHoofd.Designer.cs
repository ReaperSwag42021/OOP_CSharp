namespace CarverApp.Forms;

partial class FrmHoofd
{
    private System.ComponentModel.IContainer components = null!;
    private Label lblTitel = null!;
    private Label lblWelkom = null!;
    private Button btnNieuw = null!;
    private Button btnGepland = null!;
    private Button btnUitgevoerd = null!;
    private Button btnStatistieken = null!;
    private Button btnExportExcel = null!;
    private Button btnGebruikersbeheer = null!;
    private Button btnUitloggen = null!;

    protected override void Dispose(bool disposing)
    {
        if (disposing && (components != null))
            components.Dispose();
        base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
        lblTitel = new Label();
        lblWelkom = new Label();
        btnNieuw = new Button();
        btnGepland = new Button();
        btnUitgevoerd = new Button();
        btnStatistieken = new Button();
        btnExportExcel = new Button();
        btnGebruikersbeheer = new Button();
        btnUitloggen = new Button();
        SuspendLayout();

        lblTitel.Font = new Font("Segoe UI", 18F, FontStyle.Bold);
        lblTitel.Location = new Point(20, 15);
        lblTitel.Size = new Size(500, 38);
        lblTitel.Text = "Carver Proefrit Registratie";

        lblWelkom.Location = new Point(20, 55);
        lblWelkom.Size = new Size(500, 22);
        lblWelkom.Font = new Font("Segoe UI", 10F, FontStyle.Italic);

        Button MaakKnop(string tekst, int y, EventHandler handler)
        {
            var b = new Button
            {
                Location = new Point(40, y),
                Size = new Size(440, 48),
                Text = tekst,
                Font = new Font("Segoe UI", 11F),
                TextAlign = ContentAlignment.MiddleLeft,
                Padding = new Padding(20, 0, 0, 0),
                UseVisualStyleBackColor = true,
                Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right
            };
            b.Click += handler;
            return b;
        }

        btnNieuw            = MaakKnop("Nieuwe proefrit registreren",  100, btnNieuw_Click);
        btnGepland          = MaakKnop("Uit te voeren proefritten",    155, btnGepland_Click);
        btnUitgevoerd       = MaakKnop("Uitgevoerde proefritten",      210, btnUitgevoerd_Click);
        btnStatistieken     = MaakKnop("Statistieken / ervaring",      265, btnStatistieken_Click);
        btnExportExcel      = MaakKnop("Exporteer klantenlijst (Excel)", 320, btnExportExcel_Click);
        btnGebruikersbeheer = MaakKnop("Gebruikersbeheer (admin)",     375, btnGebruikersbeheer_Click);
        btnUitloggen        = MaakKnop("Uitloggen",                    440, btnUitloggen_Click);

        btnUitloggen.BackColor = Color.MistyRose;

        AutoScaleDimensions = new SizeF(7F, 15F);
        AutoScaleMode = AutoScaleMode.Font;
        ClientSize = new Size(520, 510);
        MinimumSize = new Size(440, 540);
        Controls.AddRange(new Control[] {
            lblTitel, lblWelkom,
            btnNieuw, btnGepland, btnUitgevoerd, btnStatistieken,
            btnExportExcel, btnGebruikersbeheer, btnUitloggen
        });
        FormBorderStyle = FormBorderStyle.Sizable;
        StartPosition = FormStartPosition.CenterScreen;
        Text = "Carver - Hoofdmenu";
        ResumeLayout(false);
    }
}
