using Microsoft.Data.SqlClient;
using CarverApp.Data;
using CarverApp.Models;

namespace CarverApp.Repositories;

public class ProspectRepository
{
    public int Toevoegen(Prospect p)
    {
        using var conn = DatabaseHelper.MaakVerbinding();
        using var cmd = new SqlCommand(
            @"INSERT INTO Prospect
                (Voornaam, Achternaam, Email, Telefoon, Adres, Postcode, Woonplaats,
                 RijbewijsAB, RijbewijsAM, Invalidenvoertuig, Motivatie)
              OUTPUT INSERTED.ProspectId
              VALUES (@vn, @an, @em, @tel, @adr, @pc, @wp, @rab, @ram, @inv, @mot)", conn);

        VulParameters(cmd, p);
        return (int)cmd.ExecuteScalar();
    }

    public void Wijzigen(Prospect p)
    {
        using var conn = DatabaseHelper.MaakVerbinding();
        using var cmd = new SqlCommand(
            @"UPDATE Prospect SET
                Voornaam=@vn, Achternaam=@an, Email=@em, Telefoon=@tel,
                Adres=@adr, Postcode=@pc, Woonplaats=@wp,
                RijbewijsAB=@rab, RijbewijsAM=@ram, Invalidenvoertuig=@inv, Motivatie=@mot
              WHERE ProspectId=@id", conn);
        VulParameters(cmd, p);
        cmd.Parameters.AddWithValue("@id", p.Id);
        cmd.ExecuteNonQuery();
    }

    public Prospect? OphalenOpId(int id)
    {
        using var conn = DatabaseHelper.MaakVerbinding();
        using var cmd = new SqlCommand(SelectColumns + " WHERE ProspectId=@id", conn);
        cmd.Parameters.AddWithValue("@id", id);
        using var reader = cmd.ExecuteReader();
        return reader.Read() ? Lees(reader) : null;
    }

    public List<Prospect> OphalenAlle()
    {
        var lijst = new List<Prospect>();
        using var conn = DatabaseHelper.MaakVerbinding();
        using var cmd = new SqlCommand(SelectColumns + " ORDER BY Achternaam, Voornaam", conn);
        using var reader = cmd.ExecuteReader();
        while (reader.Read()) lijst.Add(Lees(reader));
        return lijst;
    }

    private const string SelectColumns =
        @"SELECT ProspectId, Voornaam, Achternaam, Email, Telefoon, Adres,
                 Postcode, Woonplaats, RijbewijsAB, RijbewijsAM,
                 Invalidenvoertuig, Motivatie, AangemaaktOp
          FROM Prospect";

    private static Prospect Lees(SqlDataReader r) => new()
    {
        Id                = r.GetInt32(0),
        Voornaam          = r.GetString(1),
        Achternaam        = r.GetString(2),
        Email             = r.IsDBNull(3)  ? null : r.GetString(3),
        Telefoon          = r.IsDBNull(4)  ? null : r.GetString(4),
        Adres             = r.IsDBNull(5)  ? null : r.GetString(5),
        Postcode          = r.IsDBNull(6)  ? null : r.GetString(6),
        Woonplaats        = r.IsDBNull(7)  ? null : r.GetString(7),
        RijbewijsAB       = r.GetBoolean(8),
        RijbewijsAM       = r.GetBoolean(9),
        Invalidenvoertuig = r.GetBoolean(10),
        Motivatie         = r.IsDBNull(11) ? null : r.GetString(11),
        AangemaaktOp      = r.GetDateTime(12)
    };

    private static void VulParameters(SqlCommand cmd, Prospect p)
    {
        cmd.Parameters.AddWithValue("@vn",  p.Voornaam);
        cmd.Parameters.AddWithValue("@an",  p.Achternaam);
        cmd.Parameters.AddWithValue("@em",  (object?)p.Email      ?? DBNull.Value);
        cmd.Parameters.AddWithValue("@tel", (object?)p.Telefoon   ?? DBNull.Value);
        cmd.Parameters.AddWithValue("@adr", (object?)p.Adres      ?? DBNull.Value);
        cmd.Parameters.AddWithValue("@pc",  (object?)p.Postcode   ?? DBNull.Value);
        cmd.Parameters.AddWithValue("@wp",  (object?)p.Woonplaats ?? DBNull.Value);
        cmd.Parameters.AddWithValue("@rab", p.RijbewijsAB);
        cmd.Parameters.AddWithValue("@ram", p.RijbewijsAM);
        cmd.Parameters.AddWithValue("@inv", p.Invalidenvoertuig);
        cmd.Parameters.AddWithValue("@mot", (object?)p.Motivatie  ?? DBNull.Value);
    }
}
