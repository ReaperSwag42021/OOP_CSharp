using Microsoft.Data.SqlClient;
using CarverApp.Data;
using CarverApp.Models;

namespace CarverApp.Repositories;

public class CarverRepository
{
    public List<Carver> OphalenAlle()
    {
        var lijst = new List<Carver>();
        using var conn = DatabaseHelper.MaakVerbinding();
        using var cmd = new SqlCommand(
            @"SELECT CarverId, Model, Prijs, Omschrijving, Beschikbaar
              FROM Carver ORDER BY Prijs", conn);

        using var reader = cmd.ExecuteReader();
        while (reader.Read())
        {
            lijst.Add(new Carver
            {
                Id           = reader.GetInt32(0),
                Model        = reader.GetString(1),
                Prijs        = reader.GetDecimal(2),
                Omschrijving = reader.IsDBNull(3) ? null : reader.GetString(3),
                Beschikbaar  = reader.GetBoolean(4)
            });
        }
        return lijst;
    }

    public Carver? OphalenOpId(int id)
    {
        using var conn = DatabaseHelper.MaakVerbinding();
        using var cmd = new SqlCommand(
            @"SELECT CarverId, Model, Prijs, Omschrijving, Beschikbaar
              FROM Carver WHERE CarverId = @id", conn);
        cmd.Parameters.AddWithValue("@id", id);

        using var reader = cmd.ExecuteReader();
        if (!reader.Read()) return null;
        return new Carver
        {
            Id           = reader.GetInt32(0),
            Model        = reader.GetString(1),
            Prijs        = reader.GetDecimal(2),
            Omschrijving = reader.IsDBNull(3) ? null : reader.GetString(3),
            Beschikbaar  = reader.GetBoolean(4)
        };
    }
}
