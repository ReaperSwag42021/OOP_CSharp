using Microsoft.Data.SqlClient;
using CarverApp.Data;
using CarverApp.Models;

namespace CarverApp.Repositories;

public class ProefritRepository
{
    public int Toevoegen(Proefrit p)
    {
        using var conn = DatabaseHelper.MaakVerbinding();
        using var cmd = new SqlCommand(
            @"INSERT INTO Proefrit (ProspectId, CarverId, DatumTijd, Status, Bevestigd, Opmerkingen)
              OUTPUT INSERTED.ProefritId
              VALUES (@pid, @cid, @dt, @st, @bev, @opm)", conn);

        cmd.Parameters.AddWithValue("@pid", p.ProspectId);
        cmd.Parameters.AddWithValue("@cid", p.CarverId);
        cmd.Parameters.AddWithValue("@dt",  p.DatumTijd);
        cmd.Parameters.AddWithValue("@st",  p.Status.ToString());
        cmd.Parameters.AddWithValue("@bev", p.Bevestigd);
        cmd.Parameters.AddWithValue("@opm", (object?)p.Opmerkingen ?? DBNull.Value);
        return (int)cmd.ExecuteScalar();
    }

    public void Wijzigen(Proefrit p)
    {
        using var conn = DatabaseHelper.MaakVerbinding();
        using var cmd = new SqlCommand(
            @"UPDATE Proefrit SET
                CarverId=@cid, DatumTijd=@dt, Status=@st, Bevestigd=@bev, Opmerkingen=@opm
              WHERE ProefritId=@id", conn);

        cmd.Parameters.AddWithValue("@cid", p.CarverId);
        cmd.Parameters.AddWithValue("@dt",  p.DatumTijd);
        cmd.Parameters.AddWithValue("@st",  p.Status.ToString());
        cmd.Parameters.AddWithValue("@bev", p.Bevestigd);
        cmd.Parameters.AddWithValue("@opm", (object?)p.Opmerkingen ?? DBNull.Value);
        cmd.Parameters.AddWithValue("@id",  p.Id);
        cmd.ExecuteNonQuery();
    }

    public void Afronden(int proefritId)
    {
        using var conn = DatabaseHelper.MaakVerbinding();
        using var cmd = new SqlCommand(
            "UPDATE Proefrit SET Status='Uitgevoerd' WHERE ProefritId=@id", conn);
        cmd.Parameters.AddWithValue("@id", proefritId);
        cmd.ExecuteNonQuery();
    }

    public void Verwijderen(int id)
    {
        using var conn = DatabaseHelper.MaakVerbinding();
        using var cmd = new SqlCommand("DELETE FROM Proefrit WHERE ProefritId=@id", conn);
        cmd.Parameters.AddWithValue("@id", id);
        cmd.ExecuteNonQuery();
    }

    public List<Proefrit> OphalenOpStatus(ProefritStatus status)
    {
        var lijst = new List<Proefrit>();
        using var conn = DatabaseHelper.MaakVerbinding();
        using var cmd = new SqlCommand(
            @"SELECT pr.ProefritId, pr.ProspectId, pr.CarverId, pr.DatumTijd,
                     pr.Status, pr.Bevestigd, pr.Opmerkingen, pr.AangemaaktOp,
                     pp.Voornaam, pp.Achternaam, pp.Email, pp.Telefoon,
                     c.Model, c.Prijs
              FROM Proefrit pr
              JOIN Prospect pp ON pp.ProspectId = pr.ProspectId
              JOIN Carver   c  ON c.CarverId   = pr.CarverId
              WHERE pr.Status = @st
              ORDER BY pr.DatumTijd", conn);
        cmd.Parameters.AddWithValue("@st", status.ToString());

        using var reader = cmd.ExecuteReader();
        while (reader.Read())
        {
            lijst.Add(new Proefrit
            {
                Id           = reader.GetInt32(0),
                ProspectId   = reader.GetInt32(1),
                CarverId     = reader.GetInt32(2),
                DatumTijd    = reader.GetDateTime(3),
                Status       = Enum.Parse<ProefritStatus>(reader.GetString(4)),
                Bevestigd    = reader.GetBoolean(5),
                Opmerkingen  = reader.IsDBNull(6) ? null : reader.GetString(6),
                AangemaaktOp = reader.GetDateTime(7),
                Prospect = new Prospect
                {
                    Id         = reader.GetInt32(1),
                    Voornaam   = reader.GetString(8),
                    Achternaam = reader.GetString(9),
                    Email      = reader.IsDBNull(10) ? null : reader.GetString(10),
                    Telefoon   = reader.IsDBNull(11) ? null : reader.GetString(11),
                },
                Carver = new Carver
                {
                    Id    = reader.GetInt32(2),
                    Model = reader.GetString(12),
                    Prijs = reader.GetDecimal(13)
                }
            });
        }
        return lijst;
    }

    public Proefrit? OphalenOpId(int id)
    {
        using var conn = DatabaseHelper.MaakVerbinding();
        using var cmd = new SqlCommand(
            @"SELECT ProefritId, ProspectId, CarverId, DatumTijd, Status,
                     Bevestigd, Opmerkingen, AangemaaktOp
              FROM Proefrit WHERE ProefritId=@id", conn);
        cmd.Parameters.AddWithValue("@id", id);

        using var reader = cmd.ExecuteReader();
        if (!reader.Read()) return null;
        return new Proefrit
        {
            Id           = reader.GetInt32(0),
            ProspectId   = reader.GetInt32(1),
            CarverId     = reader.GetInt32(2),
            DatumTijd    = reader.GetDateTime(3),
            Status       = Enum.Parse<ProefritStatus>(reader.GetString(4)),
            Bevestigd    = reader.GetBoolean(5),
            Opmerkingen  = reader.IsDBNull(6) ? null : reader.GetString(6),
            AangemaaktOp = reader.GetDateTime(7),
        };
    }
}
