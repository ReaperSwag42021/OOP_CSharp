using Microsoft.Data.SqlClient;
using CarverApp.Data;
using CarverApp.Models;

namespace CarverApp.Repositories;

public class ErvaringRepository
{
    public int Opslaan(Gebruikerservaring e)
    {
        using var conn = DatabaseHelper.MaakVerbinding();
        using var cmd = new SqlCommand(
            @"INSERT INTO Gebruikerservaring
                (ProefritId, Vraag1_Rijden, Vraag2_Prijs, Vraag3_Opties, Vraag4_Aanschaf)
              OUTPUT INSERTED.ErvaringId
              VALUES (@pid, @v1, @v2, @v3, @v4)", conn);
        cmd.Parameters.AddWithValue("@pid", e.ProefritId);
        cmd.Parameters.AddWithValue("@v1",  e.Vraag1_Rijden);
        cmd.Parameters.AddWithValue("@v2",  e.Vraag2_Prijs);
        cmd.Parameters.AddWithValue("@v3",  e.Vraag3_Opties);
        cmd.Parameters.AddWithValue("@v4",  e.Vraag4_Aanschaf);
        return (int)cmd.ExecuteScalar();
    }

    public Gebruikerservaring? OphalenOpProefrit(int proefritId)
    {
        using var conn = DatabaseHelper.MaakVerbinding();
        using var cmd = new SqlCommand(
            @"SELECT ErvaringId, ProefritId, Vraag1_Rijden, Vraag2_Prijs,
                     Vraag3_Opties, Vraag4_Aanschaf, AangemaaktOp
              FROM Gebruikerservaring WHERE ProefritId=@pid", conn);
        cmd.Parameters.AddWithValue("@pid", proefritId);

        using var reader = cmd.ExecuteReader();
        if (!reader.Read()) return null;
        return new Gebruikerservaring
        {
            Id              = reader.GetInt32(0),
            ProefritId      = reader.GetInt32(1),
            Vraag1_Rijden   = reader.GetByte(2),
            Vraag2_Prijs    = reader.GetByte(3),
            Vraag3_Opties   = reader.GetByte(4),
            Vraag4_Aanschaf = reader.GetByte(5),
            AangemaaktOp   = reader.GetDateTime(6),
        };
    }

    /// <summary>
    /// Telt antwoorden per vraag (1/2/3) over alle ervaringen.
    /// Resultaat: dictionary[vraagNummer][antwoord] = aantal.
    /// </summary>
    public Dictionary<int, Dictionary<int, int>> StatistiekenPerVraag()
    {
        var totalen = new Dictionary<int, Dictionary<int, int>>();
        for (int v = 1; v <= 4; v++)
            totalen[v] = new Dictionary<int, int> { {1,0}, {2,0}, {3,0} };

        using var conn = DatabaseHelper.MaakVerbinding();
        using var cmd = new SqlCommand(
            @"SELECT Vraag1_Rijden, Vraag2_Prijs, Vraag3_Opties, Vraag4_Aanschaf
              FROM Gebruikerservaring", conn);
        using var reader = cmd.ExecuteReader();
        while (reader.Read())
        {
            totalen[1][reader.GetByte(0)]++;
            totalen[2][reader.GetByte(1)]++;
            totalen[3][reader.GetByte(2)]++;
            totalen[4][reader.GetByte(3)]++;
        }
        return totalen;
    }
}
