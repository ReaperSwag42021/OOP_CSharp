using Microsoft.Data.SqlClient;
using CarverApp.Data;
using CarverApp.Helpers;
using CarverApp.Models;

namespace CarverApp.Repositories;

public class GebruikerRepository
{
    public Gebruiker? ZoekOpGebruikersnaam(string gebruikersnaam)
    {
        using var conn = DatabaseHelper.MaakVerbinding();
        using var cmd = new SqlCommand(
            @"SELECT GebruikerId, Gebruikersnaam, WachtwoordHash, VolledigeNaam, IsAdmin, AangemaaktOp
              FROM Gebruiker WHERE Gebruikersnaam = @naam", conn);
        cmd.Parameters.AddWithValue("@naam", gebruikersnaam);

        using var reader = cmd.ExecuteReader();
        if (!reader.Read()) return null;

        bool isAdmin = reader.GetBoolean(4);
        Gebruiker g = isAdmin ? new Administrator() : new Gebruiker();
        g.Id              = reader.GetInt32(0);
        g.Gebruikersnaam  = reader.GetString(1);
        g.WachtwoordHash  = reader.GetString(2);
        g.VolledigeNaam   = reader.GetString(3);
        g.IsAdmin         = isAdmin;
        g.AangemaaktOp    = reader.GetDateTime(5);
        return g;
    }

    public List<Gebruiker> OphalenAlle()
    {
        var lijst = new List<Gebruiker>();
        using var conn = DatabaseHelper.MaakVerbinding();
        using var cmd = new SqlCommand(
            @"SELECT GebruikerId, Gebruikersnaam, WachtwoordHash, VolledigeNaam, IsAdmin, AangemaaktOp
              FROM Gebruiker ORDER BY Gebruikersnaam", conn);

        using var reader = cmd.ExecuteReader();
        while (reader.Read())
        {
            bool isAdmin = reader.GetBoolean(4);
            Gebruiker g = isAdmin ? new Administrator() : new Gebruiker();
            g.Id              = reader.GetInt32(0);
            g.Gebruikersnaam  = reader.GetString(1);
            g.WachtwoordHash  = reader.GetString(2);
            g.VolledigeNaam   = reader.GetString(3);
            g.IsAdmin         = isAdmin;
            g.AangemaaktOp    = reader.GetDateTime(5);
            lijst.Add(g);
        }
        return lijst;
    }

    public int Toevoegen(string gebruikersnaam, string wachtwoord, string volledigeNaam, bool isAdmin)
    {
        string hash = PasswordHelper.Hash(wachtwoord);
        using var conn = DatabaseHelper.MaakVerbinding();
        using var cmd = new SqlCommand(
            @"INSERT INTO Gebruiker (Gebruikersnaam, WachtwoordHash, VolledigeNaam, IsAdmin)
              OUTPUT INSERTED.GebruikerId
              VALUES (@n, @h, @v, @a)", conn);
        cmd.Parameters.AddWithValue("@n", gebruikersnaam);
        cmd.Parameters.AddWithValue("@h", hash);
        cmd.Parameters.AddWithValue("@v", volledigeNaam);
        cmd.Parameters.AddWithValue("@a", isAdmin);
        return (int)cmd.ExecuteScalar();
    }

    public void Wijzigen(int id, string volledigeNaam, bool isAdmin)
    {
        using var conn = DatabaseHelper.MaakVerbinding();
        using var cmd = new SqlCommand(
            @"UPDATE Gebruiker SET VolledigeNaam=@v, IsAdmin=@a WHERE GebruikerId=@id", conn);
        cmd.Parameters.AddWithValue("@v", volledigeNaam);
        cmd.Parameters.AddWithValue("@a", isAdmin);
        cmd.Parameters.AddWithValue("@id", id);
        cmd.ExecuteNonQuery();
    }

    public void WijzigWachtwoord(int id, string nieuwWachtwoord)
    {
        string hash = PasswordHelper.Hash(nieuwWachtwoord);
        using var conn = DatabaseHelper.MaakVerbinding();
        using var cmd = new SqlCommand(
            "UPDATE Gebruiker SET WachtwoordHash=@h WHERE GebruikerId=@id", conn);
        cmd.Parameters.AddWithValue("@h", hash);
        cmd.Parameters.AddWithValue("@id", id);
        cmd.ExecuteNonQuery();
    }

    public void Verwijderen(int id)
    {
        using var conn = DatabaseHelper.MaakVerbinding();
        using var cmd = new SqlCommand("DELETE FROM Gebruiker WHERE GebruikerId=@id", conn);
        cmd.Parameters.AddWithValue("@id", id);
        cmd.ExecuteNonQuery();
    }
}
