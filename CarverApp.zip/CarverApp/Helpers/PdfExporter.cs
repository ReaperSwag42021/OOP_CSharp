using CarverApp.Models;
using CarverApp.Repositories;
using QuestPDF.Fluent;
using QuestPDF.Helpers;
using QuestPDF.Infrastructure;

namespace CarverApp.Helpers;

/// <summary>
/// Exporteert een klantenkaart (prospect + zijn/haar proefritten) naar een PDF.
/// </summary>
public static class PdfExporter
{
    static PdfExporter()
    {
        // Community-licentie vereist; gratis voor non-commercieel of < 1M omzet.
        QuestPDF.Settings.License = LicenseType.Community;
    }

    public static void ExporteerKlantenkaart(Prospect p, List<Proefrit> proefritten, string pad)
    {
        Document.Create(doc =>
        {
            doc.Page(page =>
            {
                page.Size(PageSizes.A4);
                page.Margin(2, Unit.Centimetre);
                page.DefaultTextStyle(t => t.FontSize(11).FontFamily("Arial"));

                // ---- Header --------------------------------------------------
                page.Header().Column(col =>
                {
                    col.Item().Text("Carver Europe BV").Bold().FontSize(18).FontColor(Colors.Blue.Darken3);
                    col.Item().Text("Klantenkaart").FontSize(14).FontColor(Colors.Grey.Darken1);
                    col.Item().PaddingTop(4).LineHorizontal(1).LineColor(Colors.Grey.Lighten1);
                });

                // ---- Body ----------------------------------------------------
                page.Content().PaddingVertical(12).Column(col =>
                {
                    col.Spacing(10);

                    col.Item().Text($"Klant: {p.VolledigeNaam}").Bold().FontSize(14);

                    col.Item().Table(t =>
                    {
                        t.ColumnsDefinition(c => { c.RelativeColumn(1); c.RelativeColumn(2); });

                        void Rij(string k, string? v)
                        {
                            t.Cell().Padding(2).Text(k).SemiBold();
                            t.Cell().Padding(2).Text(v ?? "-");
                        }

                        Rij("Email",       p.Email);
                        Rij("Telefoon",    p.Telefoon);
                        Rij("Adres",       p.Adres);
                        Rij("Postcode",    p.Postcode);
                        Rij("Woonplaats",  p.Woonplaats);
                        Rij("Rijbewijs A/B", p.RijbewijsAB ? "Ja" : "Nee");
                        Rij("Rijbewijs AM",  p.RijbewijsAM ? "Ja" : "Nee");
                        Rij("Invalidenvoertuig", p.Invalidenvoertuig ? "Ja" : "Nee");
                        Rij("Motivatie",   p.Motivatie);
                        Rij("Aangemaakt",  p.AangemaaktOp.ToString("dd-MM-yyyy HH:mm"));
                    });

                    col.Item().PaddingTop(8).Text("Proefritten").Bold().FontSize(13);

                    if (proefritten.Count == 0)
                    {
                        col.Item().Text("Geen proefritten geregistreerd.").Italic();
                    }
                    else
                    {
                        col.Item().Table(t =>
                        {
                            t.ColumnsDefinition(c =>
                            {
                                c.RelativeColumn(2);
                                c.RelativeColumn(2);
                                c.RelativeColumn(1);
                                c.RelativeColumn(3);
                            });

                            t.Header(h =>
                            {
                                h.Cell().Background(Colors.Grey.Lighten3).Padding(4).Text("Datum/tijd").Bold();
                                h.Cell().Background(Colors.Grey.Lighten3).Padding(4).Text("Carver").Bold();
                                h.Cell().Background(Colors.Grey.Lighten3).Padding(4).Text("Status").Bold();
                                h.Cell().Background(Colors.Grey.Lighten3).Padding(4).Text("Opmerkingen").Bold();
                            });

                            foreach (var pr in proefritten)
                            {
                                t.Cell().Padding(4).Text(pr.DatumTijd.ToString("dd-MM-yyyy HH:mm"));
                                t.Cell().Padding(4).Text(pr.Carver?.Model ?? "-");
                                t.Cell().Padding(4).Text(pr.StatusText);
                                t.Cell().Padding(4).Text(pr.Opmerkingen ?? "-");
                            }
                        });
                    }
                });

                // ---- Footer --------------------------------------------------
                page.Footer().AlignCenter().Text(x =>
                {
                    x.Span("Klantenkaart - gegenereerd op ").FontColor(Colors.Grey.Darken1);
                    x.Span(DateTime.Now.ToString("dd-MM-yyyy HH:mm")).FontColor(Colors.Grey.Darken1);
                    x.Span(" - pagina ").FontColor(Colors.Grey.Darken1);
                    x.CurrentPageNumber().FontColor(Colors.Grey.Darken1);
                });
            });
        }).GeneratePdf(pad);
    }
}
