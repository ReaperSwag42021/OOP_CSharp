using ClosedXML.Excel;
using CarverApp.Models;

namespace CarverApp.Helpers;

/// <summary>
/// Exporteert de klantenlijst naar een Excel-bestand (.xlsx).
/// </summary>
public static class ExcelExporter
{
    public static void ExporteerKlantenlijst(List<Prospect> prospects, string pad)
    {
        using var wb = new XLWorkbook();
        var ws = wb.Worksheets.Add("Klanten");

        // Header
        string[] headers = {
            "Id", "Voornaam", "Achternaam", "Email", "Telefoon",
            "Adres", "Postcode", "Woonplaats",
            "Rijbewijs A/B", "Rijbewijs AM", "Invalidenvoertuig",
            "Motivatie", "Aangemaakt op"
        };
        for (int i = 0; i < headers.Length; i++)
            ws.Cell(1, i + 1).Value = headers[i];

        var headerRange = ws.Range(1, 1, 1, headers.Length);
        headerRange.Style.Font.Bold = true;
        headerRange.Style.Fill.BackgroundColor = XLColor.LightGray;
        headerRange.Style.Border.BottomBorder = XLBorderStyleValues.Thin;

        // Rijen
        for (int r = 0; r < prospects.Count; r++)
        {
            var p = prospects[r];
            int row = r + 2;
            ws.Cell(row, 1).Value  = p.Id;
            ws.Cell(row, 2).Value  = p.Voornaam;
            ws.Cell(row, 3).Value  = p.Achternaam;
            ws.Cell(row, 4).Value  = p.Email ?? "";
            ws.Cell(row, 5).Value  = p.Telefoon ?? "";
            ws.Cell(row, 6).Value  = p.Adres ?? "";
            ws.Cell(row, 7).Value  = p.Postcode ?? "";
            ws.Cell(row, 8).Value  = p.Woonplaats ?? "";
            ws.Cell(row, 9).Value  = p.RijbewijsAB ? "Ja" : "Nee";
            ws.Cell(row, 10).Value = p.RijbewijsAM ? "Ja" : "Nee";
            ws.Cell(row, 11).Value = p.Invalidenvoertuig ? "Ja" : "Nee";
            ws.Cell(row, 12).Value = p.Motivatie ?? "";
            ws.Cell(row, 13).Value = p.AangemaaktOp;
            ws.Cell(row, 13).Style.DateFormat.Format = "dd-mm-yyyy hh:mm";
        }

        ws.Columns().AdjustToContents();
        ws.SheetView.FreezeRows(1);

        wb.SaveAs(pad);
    }
}
