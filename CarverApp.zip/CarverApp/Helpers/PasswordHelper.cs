using System.Security.Cryptography;
using System.Text;

namespace CarverApp.Helpers;

/// <summary>
/// Hash- en verificatiefuncties voor wachtwoorden.
/// Gebruikt SHA-256 met een per-gebruiker willekeurig 16-byte salt.
/// Opslagformaat: "base64(salt):base64(hash)".
/// </summary>
public static class PasswordHelper
{
    public static string Hash(string wachtwoord)
    {
        if (string.IsNullOrEmpty(wachtwoord))
            throw new ArgumentException("Wachtwoord mag niet leeg zijn.", nameof(wachtwoord));

        byte[] salt = RandomNumberGenerator.GetBytes(16);
        byte[] hash = BerekenHash(salt, wachtwoord);
        return $"{Convert.ToBase64String(salt)}:{Convert.ToBase64String(hash)}";
    }

    public static bool Verifieer(string wachtwoord, string opgeslagenHash)
    {
        if (string.IsNullOrEmpty(opgeslagenHash) || !opgeslagenHash.Contains(':'))
            return false;

        var delen = opgeslagenHash.Split(':', 2);
        try
        {
            byte[] salt = Convert.FromBase64String(delen[0]);
            byte[] verwacht = Convert.FromBase64String(delen[1]);
            byte[] berekend = BerekenHash(salt, wachtwoord);
            return CryptographicOperations.FixedTimeEquals(berekend, verwacht);
        }
        catch (FormatException)
        {
            return false;
        }
    }

    private static byte[] BerekenHash(byte[] salt, string wachtwoord)
    {
        byte[] pwd = Encoding.UTF8.GetBytes(wachtwoord);
        byte[] combined = new byte[salt.Length + pwd.Length];
        Buffer.BlockCopy(salt, 0, combined, 0, salt.Length);
        Buffer.BlockCopy(pwd, 0, combined, salt.Length, pwd.Length);
        return SHA256.HashData(combined);
    }
}
