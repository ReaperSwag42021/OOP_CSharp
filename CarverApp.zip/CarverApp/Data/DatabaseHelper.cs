using System.Configuration;
using Microsoft.Data.SqlClient;

namespace CarverApp.Data;

/// <summary>
/// Centrale helper voor SQL Server verbinding en query-uitvoering.
/// Maakt gebruik van parameterized queries om SQL-injectie te voorkomen.
/// </summary>
public static class DatabaseHelper
{
    public static string ConnectionString
    {
        get
        {
            var cs = ConfigurationManager.ConnectionStrings["CarverDB"]
                ?? throw new InvalidOperationException(
                    "Connection string 'CarverDB' niet gevonden in App.config.");
            return cs.ConnectionString;
        }
    }

    public static SqlConnection MaakVerbinding()
    {
        var conn = new SqlConnection(ConnectionString);
        conn.Open();
        return conn;
    }

    /// <summary>
    /// Test of de database bereikbaar is. Gooit exception bij fout.
    /// </summary>
    public static void TestVerbinding()
    {
        using var conn = MaakVerbinding();
        using var cmd = new SqlCommand("SELECT 1", conn);
        cmd.ExecuteScalar();
    }
}
