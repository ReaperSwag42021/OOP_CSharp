-- ============================================================
--  CarverDB - Database aanmaakscript
--  Auteur: Rik Postma
--  Opdracht: OOP C# - Carver Proefrit Applicatie
-- ============================================================
--  Uitvoeren in SSMS:
--   1. Open dit script
--   2. Klik 'Execute' (F5)
--   3. Database 'CarverDB' wordt aangemaakt met alle tabellen
--      en wat seed-data (5 Carver-modellen + standaard admin).
--
--  Standaard inloggegevens:
--   Gebruikersnaam: admin
--   Wachtwoord:     admin123
-- ============================================================

IF DB_ID('CarverDB') IS NOT NULL
BEGIN
    ALTER DATABASE CarverDB SET SINGLE_USER WITH ROLLBACK IMMEDIATE;
    DROP DATABASE CarverDB;
END
GO

CREATE DATABASE CarverDB;
GO

USE CarverDB;
GO

-- ---------- Gebruiker ---------------------------------------
CREATE TABLE Gebruiker (
    GebruikerId       INT IDENTITY(1,1) PRIMARY KEY,
    Gebruikersnaam    NVARCHAR(50)  NOT NULL UNIQUE,
    WachtwoordHash    NVARCHAR(255) NOT NULL,
    VolledigeNaam     NVARCHAR(100) NOT NULL,
    IsAdmin           BIT           NOT NULL DEFAULT 0,
    AangemaaktOp      DATETIME2     NOT NULL DEFAULT SYSDATETIME()
);
GO

-- ---------- Carver ------------------------------------------
CREATE TABLE Carver (
    CarverId      INT IDENTITY(1,1) PRIMARY KEY,
    Model         NVARCHAR(50)    NOT NULL,
    Prijs         DECIMAL(10,2)   NOT NULL,
    Omschrijving  NVARCHAR(500)   NULL,
    Beschikbaar   BIT             NOT NULL DEFAULT 1
);
GO

-- ---------- Prospect ----------------------------------------
CREATE TABLE Prospect (
    ProspectId         INT IDENTITY(1,1) PRIMARY KEY,
    Voornaam           NVARCHAR(50)  NOT NULL,
    Achternaam         NVARCHAR(50)  NOT NULL,
    Email              NVARCHAR(100) NULL,
    Telefoon           NVARCHAR(20)  NULL,
    Adres              NVARCHAR(100) NULL,
    Postcode           NVARCHAR(10)  NULL,
    Woonplaats         NVARCHAR(50)  NULL,
    RijbewijsAB        BIT           NOT NULL DEFAULT 0,
    RijbewijsAM        BIT           NOT NULL DEFAULT 0,
    Invalidenvoertuig  BIT           NOT NULL DEFAULT 0,
    Motivatie          NVARCHAR(500) NULL,
    AangemaaktOp       DATETIME2     NOT NULL DEFAULT SYSDATETIME()
);
GO

-- ---------- Proefrit ----------------------------------------
CREATE TABLE Proefrit (
    ProefritId    INT IDENTITY(1,1) PRIMARY KEY,
    ProspectId    INT          NOT NULL,
    CarverId      INT          NOT NULL,
    DatumTijd     DATETIME2    NOT NULL,
    Status        NVARCHAR(20) NOT NULL DEFAULT 'Gepland',
    Bevestigd     BIT          NOT NULL DEFAULT 0,
    Opmerkingen   NVARCHAR(500) NULL,
    AangemaaktOp  DATETIME2    NOT NULL DEFAULT SYSDATETIME(),
    CONSTRAINT FK_Proefrit_Prospect FOREIGN KEY (ProspectId) REFERENCES Prospect(ProspectId),
    CONSTRAINT FK_Proefrit_Carver   FOREIGN KEY (CarverId)   REFERENCES Carver(CarverId),
    CONSTRAINT CK_Proefrit_Status   CHECK (Status IN ('Gepland','Uitgevoerd','Geannuleerd'))
);
GO

-- ---------- Gebruikerservaring ------------------------------
CREATE TABLE Gebruikerservaring (
    ErvaringId       INT IDENTITY(1,1) PRIMARY KEY,
    ProefritId       INT      NOT NULL UNIQUE,
    Vraag1_Rijden    TINYINT  NOT NULL,
    Vraag2_Prijs     TINYINT  NOT NULL,
    Vraag3_Opties    TINYINT  NOT NULL,
    Vraag4_Aanschaf  TINYINT  NOT NULL,
    AangemaaktOp     DATETIME2 NOT NULL DEFAULT SYSDATETIME(),
    CONSTRAINT FK_Ervaring_Proefrit FOREIGN KEY (ProefritId) REFERENCES Proefrit(ProefritId),
    CONSTRAINT CK_Ervaring_V1 CHECK (Vraag1_Rijden  BETWEEN 1 AND 3),
    CONSTRAINT CK_Ervaring_V2 CHECK (Vraag2_Prijs   BETWEEN 1 AND 3),
    CONSTRAINT CK_Ervaring_V3 CHECK (Vraag3_Opties  BETWEEN 1 AND 3),
    CONSTRAINT CK_Ervaring_V4 CHECK (Vraag4_Aanschaf BETWEEN 1 AND 3)
);
GO

-- ============================================================
--  Seed-data
-- ============================================================

-- 5 Carver-modellen
INSERT INTO Carver (Model, Prijs, Omschrijving, Beschikbaar) VALUES
('Carver Base',  10995.00, 'Instapmodel - praktisch en betaalbaar.', 1),
('Carver R+',    14995.00, 'Comfort-uitvoering met extra opties.',   1),
('Carver Range', 16995.00, 'Grotere accu, extra actieradius.',       1),
('Carver S+',    18995.00, 'Sportief comfort, premium uitrusting.',  1),
('Carver Sport', 21995.00, 'Topmodel: hoogste prestaties.',          1);
GO

-- Standaard admin (gebruikersnaam: admin, wachtwoord: admin123)
-- Format: base64(salt):base64(sha256(salt + utf8(wachtwoord)))
INSERT INTO Gebruiker (Gebruikersnaam, WachtwoordHash, VolledigeNaam, IsAdmin) VALUES
('admin',
 'gOOYXqsurc9zF8hUkHElDQ==:MZ6E+03PvFjmjMC03FLJSY4H54k6hPJdAbPRPzkp5m0=',
 'Standaard Beheerder',
 1);
GO

PRINT 'CarverDB succesvol aangemaakt. Login: admin / admin123';
GO
