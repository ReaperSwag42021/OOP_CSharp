using CarverApp.Data;
using CarverApp.Forms;
using CarverApp.Models;

namespace CarverApp;

internal static class Program
{
    /// <summary>
    /// De huidig ingelogde gebruiker; door alle forms te gebruiken.
    /// </summary>
    public static Gebruiker? HuidigeGebruiker { get; set; }

    [STAThread]
    static void Main()
    {
        ApplicationConfiguration.Initialize();

        // Snelle connectie-check zodat de gebruiker meteen ziet of de DB bereikbaar is.
        try
        {
            DatabaseHelper.TestVerbinding();
        }
        catch (Exception ex)
        {
            MessageBox.Show(
                "Kan geen verbinding maken met de database CarverDB.\n\n" +
                "Controleer de connection string in App.config en zorg dat het script " +
                "Database\\CarverDB.sql is uitgevoerd in SSMS.\n\n" +
                "Foutmelding:\n" + ex.Message,
                "Database-fout",
                MessageBoxButtons.OK, MessageBoxIcon.Error);
            return;
        }

        // Loop: zolang ingelogd, toon hoofdform. Bij uitloggen weer terug naar login.
        while (true)
        {
            using var login = new FrmLogin();
            if (login.ShowDialog() != DialogResult.OK || HuidigeGebruiker is null)
                return; // gebruiker heeft afgesloten

            using var hoofd = new FrmHoofd();
            hoofd.ShowDialog();

            // Bij sluiten: HuidigeGebruiker is null als er is uitgelogd.
            if (HuidigeGebruiker is null)
                continue;
            else
                return;
        }
    }
}
